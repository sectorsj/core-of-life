-- 21.1
CREATE INDEX IF NOT EXISTS idx_entity_type ON ontology.entity(type);

-- 21.2
CREATE INDEX IF NOT EXISTS idx_relation_subject ON ontology.relation(subject_id);

-- 21.3
CREATE INDEX IF NOT EXISTS idx_relation_object ON ontology.relation(object_id);

-- 21.4
CREATE INDEX IF NOT EXISTS idx_effect_target ON ontology.effect(target_id);

-- 21.5
CREATE INDEX IF NOT EXISTS idx_attribute_entity ON ontology.attribute(entity_id);

-- 21.6
CREATE INDEX IF NOT EXISTS idx_anatomical_owner ON biology.anatomical_structure(owner_id);

-- 21.7
CREATE INDEX IF NOT EXISTS idx_anatomical_type ON biology.anatomical_structure(structure_type);
