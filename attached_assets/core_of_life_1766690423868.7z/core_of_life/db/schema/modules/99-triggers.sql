CREATE OR REPLACE FUNCTION ontology.set_expires_at()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.duration_sec IS NOT NULL THEN
        NEW.expires_at := NEW.created_at + MAKE_INTERVAL(secs => NEW.duration_sec);
    ELSE
        NEW.expires_at := NULL;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_set_expires_at
BEFORE INSERT OR UPDATE OF duration_sec, created_at ON ontology.effect
FOR EACH ROW EXECUTE FUNCTION ontology.set_expires_at();

CREATE OR REPLACE FUNCTION ontology.on_effect_change()
RETURNS TRIGGER AS $$
DECLARE
    parsed RECORD;
BEGIN
    SELECT * INTO parsed FROM ontology.parse_effect_type(
        CASE WHEN TG_OP = 'DELETE' THEN OLD.effect_type ELSE NEW.effect_type END
    );
    IF parsed.domain IS NOT NULL AND parsed.key IS NOT NULL THEN
        PERFORM ontology.recalculate_attribute(
            CASE WHEN TG_OP = 'DELETE' THEN OLD.target_id ELSE NEW.target_id END,
            parsed.domain,
            parsed.key
        );
    END IF;
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_effect_recalc
AFTER INSERT OR UPDATE OR DELETE ON ontology.effect
FOR EACH ROW EXECUTE FUNCTION ontology.on_effect_change();