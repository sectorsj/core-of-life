-- 18.16 Кризисная мутация
CREATE OR REPLACE FUNCTION ontology.apply_crisis_mutation(p_character_id UUID)
RETURNS VOID AS $$
DECLARE
    mutation_type TEXT;
    target TEXT;
    effect JSONB;
    rare_mutation_id UUID;
BEGIN
    mutation_type := (ARRAY['organ', 'body_zone', 'skill', 'psyche'])[floor(random() * 4 + 1)];
    CASE mutation_type
        WHEN 'organ' THEN
            target := (ARRAY['heart', 'lungs', 'brain', 'liver'])[floor(random() * 4 + 1)];
            effect := jsonb_build_object('organ_' || target, 
                CASE WHEN random() < 0.7 THEN '+20%' ELSE '-30%' END);
        WHEN 'body_zone' THEN
            target := (ARRAY['skin', 'eyes', 'hair', 'hands'])[floor(random() * 4 + 1)];
            effect := jsonb_build_object(target || '_mutation', 'active');
        WHEN 'skill' THEN
            target := (ARRAY['athletics', 'medicine', 'arcana', 'stealth'])[floor(random() * 4 + 1)];
            effect := jsonb_build_object('skill_' || target, 
                CASE WHEN random() < 0.6 THEN '+15' ELSE '-25' END);
        WHEN 'psyche' THEN
            target := (ARRAY['courage', 'empathy', 'logic', 'intuition'])[floor(random() * 4 + 1)];
            effect := jsonb_build_object('psyche_' || target, 
                CASE WHEN random() < 0.5 THEN 'enhanced' ELSE 'impaired' END);
    END CASE;
    IF random() < 0.05 THEN
        SELECT id INTO rare_mutation_id
        FROM ontology.entity
        WHERE type = 'mutation' 
          AND metadata->>'rarity' = 'mythical'
        ORDER BY random()
        LIMIT 1;
        IF rare_mutation_id IS NOT NULL THEN
            INSERT INTO ontology.relation (subject_id, predicate, object_id)
            VALUES (p_character_id, 'has_mutation', rare_mutation_id);
            RETURN;
        END IF;
    END IF;
    INSERT INTO ontology.relation (subject_id, predicate, object_id)
    SELECT p_character_id, 'has_mutation', id
    FROM ontology.entity
    WHERE type = 'mutation' AND name = 'crisis_mutation';
END;
$$ LANGUAGE plpgsql;


-- 18.17 Проверка мутации
CREATE OR REPLACE FUNCTION ontology.check_for_mutation(p_character_id UUID)
RETURNS VOID AS $$
DECLARE
    trigger_effect RECORD;
    mutated BOOLEAN := false;
BEGIN
    FOR trigger_effect IN
        SELECT effect_type, magnitude
        FROM ontology.effect
        WHERE target_id = p_character_id
          AND active = true
          AND (expires_at IS NULL OR expires_at > NOW())
          AND effect_type LIKE 'mutation_trigger.%'
    LOOP
        DECLARE
            element TEXT := split_part(trigger_effect.effect_type, '.', 2);
            intensity FLOAT := trigger_effect.magnitude;
            mutation_chance FLOAT;
        BEGIN
            mutation_chance := GREATEST(0.05, (intensity - 0.7) * 0.3);
            IF random() < mutation_chance THEN
                PERFORM ontology.apply_targeted_mutation(p_character_id, element);
                mutated := true;
            END IF;
        END;
    END LOOP;
    IF mutated THEN
        PERFORM ontology.update_aura_rgb(p_character_id);
    END IF;
END;
$$ LANGUAGE plpgsql;


-- 18.15 Применение целевой мутации
CREATE OR REPLACE FUNCTION ontology.apply_targeted_mutation(p_character_id UUID, p_element TEXT)
RETURNS VOID AS $$
DECLARE
    genome TEXT;
    new_genome TEXT;
    locus_index INT;
    locus TEXT;
    new_locus TEXT;
    pos INT;
    new_base CHAR(1);
    element_to_locus JSONB := '{
        "earth": 1, "water": 2, "fire": 3, "air": 4,
        "electricity": 5, "light": 6, "darkness": 7
    }';
BEGIN
    SELECT metadata->>'genome' INTO genome FROM ontology.entity WHERE id = p_character_id;
    locus_index := (element_to_locus->>p_element)::INT;
    locus := split_part(genome, '|', locus_index);
    pos := (random() * 4 + 1)::INT;
    IF locus_index <= 4 THEN
        new_base := CASE WHEN random() < 0.5 THEN 'G' ELSE 'C' END;
    ELSE
        new_base := CASE WHEN random() < 0.5 THEN 'A' ELSE 'T' END;
    END IF;
    new_locus := overlay(locus placing new_base from pos for 1);
    new_genome := '';
    FOR i IN 1..7 LOOP
        IF i > 1 THEN new_genome := new_genome || '|'; END IF;
        IF i = locus_index THEN
            new_genome := new_genome || new_locus;
        ELSE
            new_genome := new_genome || split_part(genome, '|', i);
        END IF;
    END LOOP;
    UPDATE ontology.entity
    SET metadata = jsonb_set(metadata, '{genome}', to_jsonb(new_genome))
    WHERE id = p_character_id;
    PERFORM ontology.initialize_traits_from_genome(p_character_id, new_genome);
    INSERT INTO ontology.relation (subject_id, predicate, object_id)
    SELECT p_character_id, 'has_mutation', id
    FROM ontology.entity
    WHERE type = 'mutation' AND name = 'spectrum_mutation';
END;
$$ LANGUAGE plpgsql;


-- 18.11 Применение паттерна движения
CREATE OR REPLACE FUNCTION biology.use_movement_pattern(
    p_character_id UUID,
    p_pattern_name TEXT
) RETURNS TEXT AS $$
DECLARE
    pattern_id UUID;
    route TEXT[];
    qi_cost INT;
    required_organs TEXT[];
    current_qi FLOAT;
    organ_name TEXT;
    organ_health FLOAT;
    success_chance FLOAT;
BEGIN
    SELECT id, route, qi_cost, required_organs
    INTO pattern_id, route, qi_cost, required_organs
    FROM biology.movement_pattern mp
    JOIN ontology.entity e ON mp.id = e.id
    WHERE e.name = p_pattern_name;
    IF NOT FOUND THEN RETURN 'pattern_not_found'; END IF;
    SELECT current_value INTO current_qi
    FROM ontology.attribute
    WHERE entity_id = p_character_id AND domain = 'metaphysics' AND key = 'qi_flow';
    IF COALESCE(current_qi, 0) < qi_cost THEN RETURN 'not_enough_qi'; END IF;
    success_chance := 1.0;
    FOREACH organ_name IN ARRAY required_organs LOOP
        SELECT health INTO organ_health
        FROM biology.anatomical_structure
        WHERE owner_id = p_character_id AND structure_type = 'organ' AND name = organ_name;
        IF organ_health IS NULL THEN RETURN 'missing_organ: ' || organ_name; END IF;
        success_chance := success_chance * (organ_health / 100.0);
    END LOOP;
    UPDATE ontology.attribute
    SET current_value = current_value - qi_cost
    WHERE entity_id = p_character_id AND domain = 'metaphysics' AND key = 'qi_flow';
    IF random() <= success_chance THEN
        NULL;
    ELSE
        FOREACH organ_name IN ARRAY required_organs LOOP
            PERFORM biology.damage_organ(p_character_id, organ_name, 10.0 + random() * 15.0);
        END LOOP;
        RETURN 'pattern_failed_due_to_injury';
    END IF;
    INSERT INTO biology.pattern_mastery (character_id, pattern_id, proficiency, last_used)
    VALUES (p_character_id, pattern_id, 0.1, NOW())
    ON CONFLICT (character_id, pattern_id)
    DO UPDATE SET
        proficiency = LEAST(1.0, biology.pattern_mastery.proficiency + 0.01),
        last_used = NOW();
    RETURN 'success';
END;
$$ LANGUAGE plpgsql;

-- 18.10 Повреждение органа
CREATE OR REPLACE FUNCTION biology.damage_organ(p_character_id UUID, p_organ_name TEXT, p_damage FLOAT)
RETURNS VOID AS $$
BEGIN
    UPDATE biology.anatomical_structure
    SET health = GREATEST(0, health - p_damage)
    WHERE owner_id = p_character_id
      AND structure_type = 'organ'
      AND name = p_organ_name;
END;
$$ LANGUAGE plpgsql;


-- 18.9 Мутация acid_blood
CREATE OR REPLACE FUNCTION biology.apply_acid_blood_mutation(p_character_id UUID)
RETURNS VOID AS $$
DECLARE
    old_genome TEXT;
    new_genome TEXT;
    blocks TEXT[];
    fluids TEXT[];
BEGIN
    SELECT metadata->>'genome' INTO old_genome FROM ontology.entity WHERE id = p_character_id;
    blocks := biology.parse_genome(old_genome);
    fluids := string_to_array(blocks[5], ',');
    FOR i IN 1..COALESCE(array_length(fluids, 1), 0) LOOP
        IF fluids[i] = 'BLOOD' THEN
            fluids[i] := 'CORROSIVE_ICHOR';
        END IF;
    END LOOP;
    IF NOT ('CORROSIVE_ICHOR' = ANY(fluids)) THEN
        fluids := array_append(fluids, 'CORROSIVE_ICHOR');
    END IF;
    blocks[5] := array_to_string(fluids, ',');
    new_genome := array_to_string(blocks, '|');
    UPDATE ontology.entity
    SET metadata = jsonb_set(metadata, '{genome}', to_jsonb(new_genome))
    WHERE id = p_character_id;
    PERFORM biology.delta_update_anatomy(p_character_id, old_genome, new_genome);
    INSERT INTO ontology.relation (subject_id, predicate, object_id)
    SELECT p_character_id, 'has_mutation', id
    FROM ontology.entity
    WHERE type = 'mutation' AND name = 'acid_blood'
    ON CONFLICT DO NOTHING;
END;
$$ LANGUAGE plpgsql;


-- 18.7 Дельта-обновление анатомии
CREATE OR REPLACE FUNCTION biology.delta_update_anatomy(p_character_id UUID, p_old_genome TEXT, p_new_genome TEXT)
RETURNS VOID AS $$
DECLARE
    old_blocks TEXT[];
    new_blocks TEXT[];
    i INT;
    old_set TEXT[];
    new_set TEXT[];
    item TEXT;
    structure_map TEXT[] := ARRAY['cell','tissue','organ','fluid','system'];
BEGIN
    old_blocks := biology.parse_genome(p_old_genome);
    new_blocks := biology.parse_genome(p_new_genome);
    FOR i IN 2..6 LOOP
        old_set := string_to_array(old_blocks[i], ',');
        new_set := string_to_array(new_blocks[i], ',');
        FOREACH item IN ARRAY old_set LOOP
            IF item != '' AND NOT (item = ANY(new_set)) THEN
                DELETE FROM biology.anatomical_structure
                WHERE owner_id = p_character_id
                  AND structure_type = structure_map[i-1]
                  AND name = item;
            END IF;
        END LOOP;
        FOREACH item IN ARRAY new_set LOOP
            IF item != '' AND NOT (item = ANY(old_set)) THEN
                INSERT INTO biology.anatomical_structure (owner_id, structure_type, name, health)
                VALUES (p_character_id, structure_map[i-1], item, 100.0)
                ON CONFLICT DO NOTHING;
            END IF;
        END LOOP;
    END LOOP;
END;
$$ LANGUAGE plpgsql;


-- 18.6 Инициализация анатомии из генома
CREATE OR REPLACE FUNCTION biology.initialize_biology_from_genome(p_character_id UUID, p_genome TEXT)
RETURNS VOID AS $$
DECLARE
    blocks TEXT[];
    morphotype TEXT;
    items TEXT[];
    item TEXT;
    i INT;
BEGIN
    blocks := biology.parse_genome(p_genome);
    morphotype := blocks[1];
    UPDATE ontology.entity
    SET metadata = jsonb_set(COALESCE(metadata, '{}'), '{morphotype}', to_jsonb(morphotype))
    WHERE id = p_character_id;
    FOR i IN 2..6 LOOP
        items := string_to_array(blocks[i], ',');
        IF items IS NOT NULL THEN
            FOREACH item IN ARRAY items LOOP
                IF item != '' THEN
                    INSERT INTO biology.anatomical_structure (owner_id, structure_type, name, health)
                    VALUES (
                        p_character_id,
                        CASE i
                            WHEN 2 THEN 'cell'
                            WHEN 3 THEN 'tissue'
                            WHEN 4 THEN 'organ'
                            WHEN 5 THEN 'fluid'
                            WHEN 6 THEN 'system'
                        END,
                        item,
                        100.0
                    ) ON CONFLICT DO NOTHING;
                END IF;
            END LOOP;
        END IF;
    END LOOP;
    PERFORM ontology.initialize_traits_from_genome(p_character_id, array_to_string(blocks[7:13], '|'));
END;
$$ LANGUAGE plpgsql;


-- 18.4 Инициализация черт из генома
CREATE OR REPLACE FUNCTION ontology.initialize_traits_from_genome(p_character_id UUID, p_genome TEXT)
RETURNS VOID AS $$
DECLARE
    affinities JSONB;
    earth FLOAT; water FLOAT; fire FLOAT; air FLOAT;
    electricity FLOAT; light FLOAT; darkness FLOAT;
    openness FLOAT;
BEGIN
    affinities := ontology.calculate_elemental_affinity(p_genome);
    earth := (affinities->>'earth')::FLOAT;
    water := (affinities->>'water')::FLOAT;
    fire := (affinities->>'fire')::FLOAT;
    air := (affinities->>'air')::FLOAT;
    electricity := (affinities->>'electricity')::FLOAT;
    light := (affinities->>'light')::FLOAT;
    darkness := (affinities->>'darkness')::FLOAT;
    openness := GREATEST(0.01, LEAST(100.00, (earth / 10.0) * 100.0));
    INSERT INTO ontology.attribute (entity_id, domain, key, base_value, current_value)
    VALUES (p_character_id, 'metaphysics', 'chakra_muladhara_openness', openness, openness)
    ON CONFLICT DO NOTHING;
    openness := GREATEST(0.01, LEAST(100.00, (water / 10.0) * 100.0));
    INSERT INTO ontology.attribute (entity_id, domain, key, base_value, current_value)
    VALUES (p_character_id, 'metaphysics', 'chakra_svadhisthana_openness', openness, openness)
    ON CONFLICT DO NOTHING;
    openness := GREATEST(0.01, LEAST(100.00, (fire / 10.0) * 100.0));
    INSERT INTO ontology.attribute (entity_id, domain, key, base_value, current_value)
    VALUES (p_character_id, 'metaphysics', 'chakra_manipura_openness', openness, openness)
    ON CONFLICT DO NOTHING;
    openness := GREATEST(0.01, LEAST(100.00, (air / 10.0) * 100.0));
    INSERT INTO ontology.attribute (entity_id, domain, key, base_value, current_value)
    VALUES (p_character_id, 'metaphysics', 'chakra_anahata_openness', openness, openness)
    ON CONFLICT DO NOTHING;
    openness := GREATEST(0.01, LEAST(100.00, (electricity / 10.0) * 100.0));
    INSERT INTO ontology.attribute (entity_id, domain, key, base_value, current_value)
    VALUES (p_character_id, 'metaphysics', 'chakra_vishuddha_openness', openness, openness)
    ON CONFLICT DO NOTHING;
    openness := GREATEST(0.01, LEAST(100.00, (light / 10.0) * 100.0));
    INSERT INTO ontology.attribute (entity_id, domain, key, base_value, current_value)
    VALUES (p_character_id, 'metaphysics', 'chakra_ajna_openness', openness, openness)
    ON CONFLICT DO NOTHING;
    openness := GREATEST(0.01, LEAST(100.00, (darkness / 10.0) * 100.0));
    INSERT INTO ontology.attribute (entity_id, domain, key, base_value, current_value)
    VALUES (p_character_id, 'metaphysics', 'chakra_sahasrara_openness', openness, openness)
    ON CONFLICT DO NOTHING;
    UPDATE ontology.entity
    SET metadata = jsonb_set(metadata, '{elemental_affinity}', affinities)
    WHERE id = p_character_id;
END;
$$ LANGUAGE plpgsql;


-- 18.5 Парсинг генома с анатомией
CREATE OR REPLACE FUNCTION biology.parse_genome(p_genome TEXT, OUT blocks TEXT[])
AS $$
BEGIN
    blocks := string_to_array(p_genome, '|');
    IF array_length(blocks, 1) < 8 THEN
        RAISE EXCEPTION 'Invalid genome: expected at least 8 blocks';
    END IF;
END;
$$ LANGUAGE plpgsql IMMUTABLE;


-- 18.8 Создание ребёнка
CREATE OR REPLACE FUNCTION ontology.create_child(
    p_father_id UUID,
    p_mother_id UUID,
    p_name TEXT
)
RETURNS UUID AS $$
DECLARE
    child_id UUID;
    father_genome TEXT;
    mother_genome TEXT;
    father_blocks TEXT[];
    mother_blocks TEXT[];
    child_blocks TEXT[13];
    i INT;
    father_items TEXT[];
    mother_items TEXT[];
    combined_items TEXT[];
    chosen TEXT;
BEGIN
    SELECT metadata->>'genome' INTO father_genome FROM ontology.entity WHERE id = p_father_id;
    SELECT metadata->>'genome' INTO mother_genome FROM ontology.entity WHERE id = p_mother_id;
    father_blocks := string_to_array(father_genome, '|');
    mother_blocks := string_to_array(mother_genome, '|');
    child_blocks[1] := CASE WHEN random() < 0.8 THEN father_blocks[1] ELSE mother_blocks[1] END;
    FOR i IN 2..6 LOOP
        father_items := string_to_array(father_blocks[i], ',');
        mother_items := string_to_array(mother_blocks[i], ',');
        SELECT array_agg(DISTINCT x) INTO combined_items
        FROM unnest(array_cat(father_items, mother_items)) AS x
        WHERE x != '';
        IF combined_items IS NOT NULL THEN
            chosen := '';
            FOR j IN 1..array_length(combined_items, 1) LOOP
                IF random() < 0.7 THEN
                    IF chosen = '' THEN
                        chosen := combined_items[j];
                    ELSE
                        chosen := chosen || ',' || combined_items[j];
                    END IF;
                END IF;
            END LOOP;
            child_blocks[i] := chosen;
        ELSE
            child_blocks[i] := '';
        END IF;
    END LOOP;
    FOR i IN 7..13 LOOP
        DECLARE
            f_locus TEXT := father_blocks[i];
            m_locus TEXT := mother_blocks[i];
            child_locus TEXT := '';
            base1 CHAR(1); base2 CHAR(1); base3 CHAR(1); base4 CHAR(1);
        BEGIN
            base1 := CASE WHEN random() < 0.5 THEN substr(f_locus, 1, 1) ELSE substr(m_locus, 1, 1) END;
            base2 := CASE WHEN random() < 0.5 THEN substr(f_locus, 2, 1) ELSE substr(m_locus, 2, 1) END;
            base3 := CASE WHEN random() < 0.5 THEN substr(f_locus, 3, 1) ELSE substr(m_locus, 3, 1) END;
            base4 := CASE WHEN random() < 0.5 THEN substr(f_locus, 4, 1) ELSE substr(m_locus, 4, 1) END;
            child_locus := base1 || base2 || base3 || base4;
            child_blocks[i] := child_locus;
        END;
    END LOOP;
    INSERT INTO ontology.entity (type, name, metadata, age, status, timeline)
    VALUES (
        'character',
        p_name,
        jsonb_build_object('genome', array_to_string(child_blocks, '|')),
        0,
        'alive',
        'present'
    )
    RETURNING id INTO child_id;
    INSERT INTO ontology.relation (subject_id, predicate, object_id)
    VALUES (child_id, 'child_of', p_father_id), (child_id, 'child_of', p_mother_id);
    PERFORM biology.initialize_biology_from_genome(child_id, array_to_string(child_blocks, '|'));
    RETURN child_id;
END;
$$ LANGUAGE plpgsql;


