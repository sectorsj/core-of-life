-- 14.2
CREATE INDEX idx_anatomical_owner ON biology.anatomical_structure(owner_id);

-- 14.3
CREATE INDEX idx_anatomical_type ON biology.anatomical_structure(structure_type);
