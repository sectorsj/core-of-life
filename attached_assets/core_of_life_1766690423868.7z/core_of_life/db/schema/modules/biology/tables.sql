-- === 14. АНАТОМИЧЕСКИЕ СТРУКТУРЫ ===
-- Анатомическая структура
CREATE TABLE biology.anatomical_structure (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    structure_type TEXT NOT NULL CHECK (structure_type IN ('cell', 'tissue', 'organ', 'fluid', 'system')),
    name TEXT NOT NULL,
    subtype TEXT,
    health FLOAT NOT NULL DEFAULT 100.0 CHECK (health BETWEEN 0 AND 100),
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Паттерн движения
CREATE TABLE biology.movement_pattern (
    id UUID PRIMARY KEY REFERENCES ontology.entity(id) ON DELETE CASCADE,
    route TEXT[] NOT NULL,
    qi_cost INT NOT NULL DEFAULT 5,
    cooldown_sec INT DEFAULT 2,
    required_organs TEXT[]
);


-- Улучшение двигательного паттерна
CREATE TABLE biology.pattern_mastery (
    character_id UUID REFERENCES ontology.entity(id) ON DELETE CASCADE,
    pattern_id UUID REFERENCES ontology.entity(id) ON DELETE CASCADE,
    proficiency FLOAT NOT NULL DEFAULT 0.0 CHECK (proficiency BETWEEN 0 AND 1),
    last_used TIMESTAMPTZ,
    PRIMARY KEY (character_id, pattern_id)
);