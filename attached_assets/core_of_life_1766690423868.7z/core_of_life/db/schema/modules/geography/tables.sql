-- === 4. ГЕОГРАФИЯ ===
-- 4.1
CREATE TABLE geography.region_vertex (
    id SERIAL PRIMARY KEY,
    region_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    elevation DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    vertex_order INT NOT NULL,
    UNIQUE(region_id, vertex_order)
);