-- 18.23 Применение эффектов чакр
CREATE OR REPLACE FUNCTION ontology.apply_chakra_effects(p_character_id UUID)
RETURNS VOID AS $$
DECLARE
    chakra RECORD;
    effect_type TEXT;
    magnitude FLOAT;
BEGIN
    FOR chakra IN
        SELECT key, current_value
        FROM ontology.attribute
        WHERE entity_id = p_character_id
          AND domain = 'metaphysics'
          AND key LIKE 'chakra_%_openness'
    LOOP
        CASE
            WHEN chakra.key = 'chakra_muladhara_openness' THEN
                effect_type := 'biology.body_strength';
                magnitude := 10;
            WHEN chakra.key = 'chakra_anahata_openness' THEN
                effect_type := 'metaphysics.aura_radius';
                magnitude := 2.0;
            WHEN chakra.key = 'chakra_ajna_openness' THEN
                effect_type := 'noosphere.mana_regen';
                magnitude := 5;
            ELSE
                effect_type := NULL;
        END CASE;
        IF effect_type IS NOT NULL THEN
            IF chakra.current_value >= 70.0 THEN
                INSERT INTO ontology.effect (
                    source_id, target_id, domain, effect_type, magnitude, operation, active
                ) VALUES (
                    p_character_id,
                    p_character_id,
                    split_part(effect_type, '.', 1),
                    effect_type,
                    magnitude,
                    'add',
                    true
                ) ON CONFLICT DO NOTHING;
            ELSIF chakra.current_value >= 30.0 THEN
                INSERT INTO ontology.effect (
                    source_id, target_id, domain, effect_type, magnitude, operation, active
                ) VALUES (
                    p_character_id,
                    p_character_id,
                    split_part(effect_type, '.', 1),
                    effect_type,
                    magnitude * 0.5,
                    'add',
                    true
                ) ON CONFLICT DO NOTHING;
            END IF;
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql;


-- 18.24 Выбор чакры от наблюдателя
CREATE OR REPLACE FUNCTION ontology.select_chakra_for_observer(
    p_character_id UUID,
    p_chakra_name TEXT,
    p_observer_id UUID
)
RETURNS TEXT AS $$
DECLARE
    openness FLOAT;
BEGIN
    IF NOT EXISTS (SELECT 1 FROM ontology.observer WHERE id = p_observer_id) THEN
        RETURN 'invalid_observer';
    END IF;
    CASE p_chakra_name
        WHEN 'muladhara' THEN
            INSERT INTO ontology.effect (source_id, target_id, domain, effect_type, magnitude, operation)
            VALUES (p_observer_id, p_character_id, 'biology', 'body_strength', 5, 'add');
        WHEN 'anahata' THEN
            INSERT INTO ontology.effect (source_id, target_id, domain, effect_type, magnitude, operation)
            VALUES (p_observer_id, p_character_id, 'metaphysics', 'aura_radius', 1.0, 'add');
        WHEN 'sahasrara' THEN
            PERFORM ontology.transform_egregor_energy(p_character_id, (SELECT object_id FROM ontology.relation WHERE subject_id = p_character_id AND predicate = 'connected_to_egregor' LIMIT 1));
        ELSE
    END CASE;
    UPDATE ontology.comment
    SET influence = influence + 0.05
    WHERE observer_id = p_observer_id AND target_id = p_character_id;
    RETURN 'success';
END;
$$ LANGUAGE plpgsql;


-- 18.26 Трансформация энергии маятника
CREATE OR REPLACE FUNCTION ontology.transform_egregor_energy(p_character_id UUID, p_egregor_id UUID)
RETURNS VOID AS $$
DECLARE
    energy FLOAT;
    chakra RECORD;
BEGIN
    SELECT (metadata->>'power')::FLOAT INTO energy
    FROM ontology.entity
    WHERE id = p_egregor_id;
    UPDATE ontology.attribute
    SET current_value = LEAST(100, current_value + energy * 2)
    WHERE entity_id = p_character_id
      AND domain = 'metaphysics'
      AND key = 'qi_flow';
    FOR chakra IN
        SELECT key
        FROM ontology.attribute
        WHERE entity_id = p_character_id
          AND domain = 'metaphysics'
          AND key LIKE 'chakra_%_openness'
    LOOP
        UPDATE ontology.attribute
        SET current_value = LEAST(100.00, current_value + energy * 0.5)
        WHERE entity_id = p_character_id
          AND domain = 'metaphysics'
          AND key = chakra.key;
    END LOOP;
    UPDATE ontology.entity
    SET metadata = jsonb_set(metadata, '{power}', '0')
    WHERE id = p_egregor_id;
    DELETE FROM ontology.relation
    WHERE subject_id = p_character_id
      AND predicate = 'connected_to_egregor'
      AND object_id = p_egregor_id;
    PERFORM ontology.update_aura_rgb(p_character_id);
END;
$$ LANGUAGE plpgsql;


-- 18.37 Обновление ауры
CREATE OR REPLACE FUNCTION ontology.update_aura_rgb(p_character_id UUID)
RETURNS VOID AS $$
DECLARE
    spectrum JSONB;
BEGIN
    SELECT metadata->'spectrum' INTO spectrum FROM ontology.entity WHERE id = p_character_id;
    IF spectrum IS NULL THEN RETURN; END IF;
    UPDATE ontology.entity
    SET metadata = jsonb_set(COALESCE(metadata, '{}'), '{aura_rgb}', ontology.spectrum_to_rgb(spectrum))
    WHERE id = p_character_id;
END;
$$ LANGUAGE plpgsql;


-- 18.36 Спектрум → RGB
CREATE OR REPLACE FUNCTION ontology.spectrum_to_rgb(spectrum JSONB)
RETURNS JSONB AS $$
DECLARE
    total_r INT := 0; total_g INT := 0; total_b INT := 0;
    color TEXT; intensity FLOAT; rgb RECORD;
BEGIN
    FOR color IN SELECT jsonb_object_keys(spectrum) LOOP
        intensity := GREATEST(0, LEAST(1, (spectrum->>color)::FLOAT));
        SELECT r, g, b INTO rgb FROM ontology.spectrum_rgb WHERE color_key = color;
        IF FOUND THEN
            total_r := total_r + (rgb.r * intensity)::INT;
            total_g := total_g + (rgb.g * intensity)::INT;
            total_b := total_b + (rgb.b * intensity)::INT;
        END IF;
    END LOOP;
    total_r := LEAST(255, total_r);
    total_g := LEAST(255, total_g);
    total_b := LEAST(255, total_b);
    RETURN jsonb_build_object('r', total_r, 'g', total_g, 'b', total_b);
END;
$$ LANGUAGE plpgsql;


-- 18.20 Добавление крючка к маятнику
CREATE OR REPLACE FUNCTION ontology.add_hook_to_egregor(
    p_egregor_id UUID,
    p_hook TEXT,
    p_weights_json JSONB
)
RETURNS VOID AS $$
DECLARE
    current_hooks JSONB;
    current_weights JSONB;
BEGIN
    SELECT COALESCE(metadata->'hooks', '[]'::jsonb) INTO current_hooks
    FROM ontology.entity
    WHERE id = p_egregor_id;
    IF NOT (current_hooks ? p_hook) THEN
        current_hooks := current_hooks || to_jsonb(p_hook);
        UPDATE ontology.entity
        SET metadata = jsonb_set(metadata, '{hooks}', current_hooks)
        WHERE id = p_egregor_id;
    END IF;
    SELECT COALESCE(metadata->'hook_weights', '{}'::jsonb) INTO current_weights
    FROM ontology.entity
    WHERE id = p_egregor_id;
    current_weights := jsonb_set(current_weights, ARRAY[p_hook], p_weights_json);
    UPDATE ontology.entity
    SET metadata = jsonb_set(metadata, '{hook_weights}', current_weights)
    WHERE id = p_egregor_id;
END;
$$ LANGUAGE plpgsql;


-- 18.19 Ритуал призыва Хранителя
CREATE OR REPLACE FUNCTION ontology.perform_keeper_ritual(
    p_character_id UUID,
    p_ritual_id UUID
)
RETURNS TEXT AS $$
DECLARE
    ritual_data JSONB;
    keeper_name TEXT;
    keeper_id UUID;
    required_karma INT;
    current_karma FLOAT;
    has_item BOOLEAN := false;
    in_location BOOLEAN := false;
BEGIN
    SELECT metadata INTO ritual_data FROM ontology.entity WHERE id = p_ritual_id;
    keeper_name := ritual_data->>'keeper';
    required_karma := (ritual_data->>'required_karma')::INT;
    SELECT id INTO keeper_id FROM ontology.entity WHERE name = keeper_name;
    SELECT current_value INTO current_karma
    FROM ontology.attribute
    WHERE entity_id = p_character_id
      AND domain = 'metaphysics'
      AND key = 'keeper_karma_' || keeper_id;
    IF COALESCE(current_karma, 0) < required_karma THEN
        RETURN 'insufficient_karma';
    END IF;
    IF ritual_data ? 'required_item' THEN
        SELECT EXISTS (
            SELECT 1 FROM ontology.relation r
            JOIN ontology.entity item ON r.object_id = item.id
            WHERE r.subject_id = p_character_id
              AND r.predicate = 'possesses'
              AND item.name = ritual_data->>'required_item'
        ) INTO has_item;
        IF NOT has_item THEN
            RETURN 'missing_ritual_item';
        END IF;
    END IF;
    IF ritual_data ? 'required_location' THEN
        SELECT EXISTS (
            SELECT 1 FROM ontology.relation r
            JOIN ontology.entity loc ON r.object_id = loc.id
            WHERE r.subject_id = p_character_id
              AND r.predicate = 'located_in'
              AND loc.metadata->>'type' = ritual_data->>'required_location'
        ) INTO in_location;
        IF NOT in_location THEN
            RETURN 'wrong_location';
        END IF;
    END IF;
    INSERT INTO ontology.effect (
        source_id, target_id, domain, effect_type, magnitude, duration_sec, operation
    ) VALUES (
        keeper_id,
        p_character_id,
        'metaphysics',
        'keeper_presence.' || keeper_name,
        1.0,
        (ritual_data->>'duration_sec')::INT,
        'set'
    );
    INSERT INTO ontology.notification (
        character_id, title, message, source_id
    ) VALUES (
        p_character_id,
        'Ритуал завершён',
        keeper_name || ' откликнулся на ваш зов.',
        keeper_id
    );
    RETURN 'success';
END;
$$ LANGUAGE plpgsql;


-- 18.18 Обновление кармы Хранителя
CREATE OR REPLACE FUNCTION ontology.update_keeper_karma(
    p_character_id UUID,
    p_keeper_id UUID,
    p_change FLOAT
)
RETURNS VOID AS $$
DECLARE
    current_val FLOAT;
BEGIN
    SELECT current_value INTO current_val
    FROM ontology.attribute
    WHERE entity_id = p_character_id
      AND domain = 'metaphysics'
      AND key = 'keeper_karma_' || p_keeper_id;
    IF current_val IS NULL THEN
        INSERT INTO ontology.attribute (entity_id, domain, key, base_value, current_value)
        VALUES (p_character_id, 'metaphysics', 'keeper_karma_' || p_keeper_id, 50, 50 + p_change);
    ELSE
        UPDATE ontology.attribute
        SET current_value = GREATEST(0, LEAST(100, current_val + p_change))
        WHERE entity_id = p_character_id
          AND domain = 'metaphysics'
          AND key = 'keeper_karma_' || p_keeper_id;
    END IF;
END;
$$ LANGUAGE plpgsql;


-- 18.14 Очищение
CREATE OR REPLACE FUNCTION ontology.perform_cleansing(
    p_character_id UUID,
    p_cleansing_type TEXT
)
RETURNS TEXT AS $$
DECLARE
    will_recovery FLOAT;
    chakra_recovery FLOAT;
BEGIN
    CASE p_cleansing_type
        WHEN 'meditation' THEN
            will_recovery := 15;
            chakra_recovery := 20.0;
        WHEN 'sacrifice_ritual' THEN
            IF (SELECT SUM(amount * (metadata->>'value_in_base')::INT)
                FROM technosphere.coin_purse cp
                JOIN ontology.entity coin ON cp.coin_type_id = coin.id
                WHERE cp.character_id = p_character_id) < 50 THEN
                RETURN 'insufficient_funds';
            END IF;
            UPDATE technosphere.coin_purse
            SET amount = GREATEST(0, amount - 50 / (SELECT (metadata->>'value_in_base')::INT FROM ontology.entity WHERE id = coin_type_id))
            WHERE character_id = p_character_id;
            will_recovery := 25;
            chakra_recovery := 30.0;
        WHEN 'virtue_deed' THEN
            IF NOT EXISTS (
                SELECT 1 FROM ontology.relation r
                JOIN ontology.entity q ON r.object_id = q.id
                WHERE r.subject_id = p_character_id
                  AND r.predicate = 'completed_quest'
                  AND q.metadata->'tags' ? 'virtue_deed'
            ) THEN
                RETURN 'virtue_deed_not_completed';
            END IF;
            will_recovery := 30;
            chakra_recovery := 40.0;
        ELSE
            RETURN 'unknown_cleansing_type';
    END CASE;
    UPDATE ontology.attribute
    SET current_value = LEAST(100, current_value + will_recovery)
    WHERE entity_id = p_character_id AND domain = 'anthroposphere' AND key = 'willpower';
    UPDATE ontology.attribute
    SET current_value = LEAST(100.00, current_value + chakra_recovery)
    WHERE entity_id = p_character_id AND domain = 'metaphysics' AND key LIKE 'chakra_%_openness';
    RETURN 'success';
END;
$$ LANGUAGE plpgsql;