-- === 6. Справочник цветов Спектрума (RGB) ===

-- Цвета Спектрума
CREATE TABLE ontology.spectrum_rgb (
    color_key TEXT PRIMARY KEY,
    r INT, g INT, b INT
);