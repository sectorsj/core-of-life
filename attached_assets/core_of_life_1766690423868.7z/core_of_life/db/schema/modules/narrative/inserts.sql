-- Шаблоны сцен
INSERT INTO ontology.scene_template (trigger_event, target_chakra, camera, effects)
VALUES (
    'chakra_activation',
    'sahasrara',
    '{"angle": "low_angle", "zoom": "extreme_closeup", "motion": "slow_rise"}',
    '[{"type": "aura_pulse", "color": "violet", "intensity": 1.5},
      {"type": "reality_rift", "duration_sec": 3}]'
);