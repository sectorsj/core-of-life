-- === 17. Сцены и речь ===

-- Шаблон сцены
CREATE TABLE ontology.scene_template (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trigger_event TEXT NOT NULL,
    target_chakra TEXT,
    camera JSONB NOT NULL,
    effects JSONB NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);


-- === 12. Уведомления ===
-- 12.1
CREATE TABLE ontology.notification (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    character_id UUID NOT NULL REFERENCES ontology.entity(id),
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    source_id UUID REFERENCES ontology.entity(id),
    action_required BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);


-- === 11. Активные выборы ===
-- 11.1
CREATE TABLE ontology.active_choice (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    character_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    available_chakras TEXT[] NOT NULL,
    observer_id UUID REFERENCES ontology.observer(id),
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);