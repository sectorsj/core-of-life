-- 18.25 Голоса ноосферы
CREATE OR REPLACE FUNCTION ontology.get_noosphere_influence(p_character_id UUID, p_key TEXT)
RETURNS FLOAT AS $$
DECLARE
    total_influence FLOAT := 0;
BEGIN
    SELECT COALESCE(SUM(c.influence), 0)
    INTO total_influence
    FROM ontology.comment c
    JOIN ontology.observer o ON c.observer_id = o.id
    WHERE c.target_id = p_character_id
      AND c.content ILIKE '%' || p_key || '%';
    RETURN total_influence;
END;
$$ LANGUAGE plpgsql;