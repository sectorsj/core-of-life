-- === 10. Наблюдатели и ЭМ ===
-- 10.1
CREATE TABLE ontology.observer (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID NOT NULL REFERENCES auth.account(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10.2
CREATE TABLE ontology.electrum_balance (
    observer_id UUID PRIMARY KEY REFERENCES ontology.observer(id) ON DELETE CASCADE,
    balance INT NOT NULL DEFAULT 0
);

-- 10.3
CREATE TABLE ontology.electrum_transaction (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    observer_id UUID NOT NULL REFERENCES ontology.observer(id),
    target_id UUID NOT NULL REFERENCES ontology.entity(id),
    amount INT NOT NULL CHECK (amount > 0),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10.4
CREATE TABLE ontology.comment (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    observer_id UUID NOT NULL REFERENCES ontology.observer(id),
    target_id UUID NOT NULL REFERENCES ontology.entity(id),
    content TEXT NOT NULL,
    influence FLOAT DEFAULT 0.1,
    created_at TIMESTAMPTZ DEFAULT NOW()
);