
-- 18.1 Парсинг effect_type
CREATE OR REPLACE FUNCTION ontology.parse_effect_type(effect_type TEXT, OUT domain TEXT, OUT key TEXT)
AS $$
BEGIN
    IF effect_type LIKE '%.%' THEN
        domain := split_part(effect_type, '.', 1);
        key := split_part(effect_type, '.', 2);
    ELSE
        domain := NULL;
        key := NULL;
    END IF;
END;
$$ LANGUAGE plpgsql IMMUTABLE;


-- 18.2 Пересчёт атрибута
CREATE OR REPLACE FUNCTION ontology.recalculate_attribute(p_entity_id UUID, p_domain TEXT, p_key TEXT)
RETURNS VOID AS $$
DECLARE
    base_val FLOAT;
    final_val FLOAT;
    eff RECORD;
BEGIN
    SELECT base_value INTO base_val
    FROM ontology.attribute
    WHERE entity_id = p_entity_id AND domain = p_domain AND key = p_key;
    IF base_val IS NULL THEN RETURN; END IF;
    final_val := base_val;
    FOR eff IN
        SELECT e.magnitude, e.operation
        FROM ontology.effect e
        WHERE e.target_id = p_entity_id
          AND e.active = true
          AND (e.expires_at IS NULL OR e.expires_at > NOW())
          AND e.effect_type = p_domain || '.' || p_key
    LOOP
        CASE eff.operation
            WHEN 'add' THEN final_val := final_val + eff.magnitude;
            WHEN 'multiply' THEN final_val := final_val * eff.magnitude;
            WHEN 'set' THEN final_val := eff.magnitude;
        END CASE;
    END LOOP;
    UPDATE ontology.attribute
    SET current_value = final_val, last_updated = NOW()
    WHERE entity_id = p_entity_id AND domain = p_domain AND key = p_key;
END;
$$ LANGUAGE plpgsql;


-- 18.3 Расчёт аффинити к стихиям из генома
CREATE OR REPLACE FUNCTION ontology.calculate_elemental_affinity(p_genome TEXT)
RETURNS JSONB AS $$
DECLARE
    affinities JSONB := '{
        "earth": 0, "water": 0, "fire": 0, "air": 0,
        "electricity": 0, "light": 0, "darkness": 0
    }';
    locus TEXT;
    score FLOAT;
    bases TEXT[] := ARRAY['earth', 'water', 'fire', 'air', 'electricity', 'light', 'darkness'];
    i INT;
BEGIN
    FOR i IN 1..7 LOOP
        locus := split_part(p_genome, '|', i);
        score := (
            (LENGTH(locus) - LENGTH(REPLACE(locus, 'G', ''))) * 1.5 +
            (LENGTH(locus) - LENGTH(REPLACE(locus, 'C', ''))) * 1.5 +
            (LENGTH(locus) - LENGTH(REPLACE(locus, 'A', ''))) * 1.0 +
            (LENGTH(locus) - LENGTH(REPLACE(locus, 'T', ''))) * 1.0
        );
        affinities := jsonb_set(affinities, ARRAY[bases[i]], to_jsonb(score));
    END LOOP;
    RETURN affinities;
END;
$$ LANGUAGE plpgsql;


-- 2.4
CREATE OR REPLACE FUNCTION ontology.set_expires_at()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.duration_sec IS NOT NULL THEN
        NEW.expires_at := NEW.created_at + MAKE_INTERVAL(secs => NEW.duration_sec);
    ELSE
        NEW.expires_at := NULL;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_set_expires_at
BEFORE INSERT OR UPDATE OF duration_sec, created_at ON ontology.effect
FOR EACH ROW EXECUTE FUNCTION ontology.set_expires_at();