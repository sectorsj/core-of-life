-- 7.2
INSERT INTO ontology.entity (type, name, metadata) VALUES
('chakra', 'muladhara',   '{"need": "physiology", "spectrum": "earth"}'),
('chakra', 'svadhisthana', '{"need": "safety", "spectrum": "water"}'),
('chakra', 'manipura',    '{"need": "belonging", "spectrum": "fire"}'),
('chakra', 'anahata',     '{"need": "esteem", "spectrum": "air"}'),
('chakra', 'vishuddha',   '{"need": "cognition", "spectrum": "electricity"}'),
('chakra', 'ajna',        '{"need": "aesthetics", "spectrum": "light"}'),
('chakra', 'sahasrara',   '{"need": "self_actualization", "spectrum": "darkness"}');

-- 7.3
INSERT INTO ontology.entity (type, name) VALUES
('worldview_key', 'duty'),
('worldview_key', 'freedom'),
('worldview_key', 'sacrifice'),
('worldview_key', 'power'),
('worldview_key', 'truth');

-- 7.4
INSERT INTO ontology.entity (type, name, metadata) VALUES
('egregor', 'Война', '{
  "description": "Маятник конфликта",
  "hooks": ["кто", "что", "куда", "сколько", "откуда", "зачем", "почему"],
  "hook_weights": {
    "кто": {"manipura": 0.9, "anahata": 0.6},
    "что": {"muladhara": 0.9, "svadhisthana": 0.7},
    "куда": {"svadhisthana": 0.9, "muladhara": 0.5},
    "сколько": {"anahata": 0.8, "ajna": 0.5},
    "откуда": {"vishuddha": 0.9, "sahasrara": 0.6},
    "зачем": {"sahasrara": 0.9, "anahata": 0.7},
    "почему": {"ajna": 0.9, "vishuddha": 0.8}
  },
  "feeds_on": ["гнев", "страх"],
  "feeds_on_complex": ["ненависть", "воинственность", "тревожность"],
  "power": 0
}'),
('egregor', 'Семья', '{
  "description": "Маятник родственных связей",
  "hooks": ["кто", "что", "куда", "сколько", "откуда", "зачем", "почему"],
  "hook_weights": {
    "кто": {"manipura": 0.8, "anahata": 0.9},
    "что": {"muladhara": 0.5, "anahata": 0.6},
    "куда": {"svadhisthana": 0.7, "anahata": 0.6},
    "сколько": {"anahata": 0.7, "manipura": 0.6},
    "откуда": {"vishuddha": 0.6, "manipura": 0.4},
    "зачем": {"sahasrara": 0.6, "anahata": 0.8},
    "почему": {"ajna": 0.7, "anahata": 0.5}
  },
  "feeds_on": ["стыд", "вина", "доверие"],
  "feeds_on_complex": ["любовь", "сострадание", "одиночество"],
  "power": 0
}'),
('egregor', 'Знание', '{
  "description": "Маятник истины",
  "hooks": ["кто", "что", "куда", "сколько", "откуда", "зачем", "почему"],
  "hook_weights": {
    "кто": {"vishuddha": 0.7, "ajna": 0.8, "sahasrara": 0.9},
    "что": {"muladhara": 0.6, "vishuddha": 0.8},
    "куда": {"ajna": 0.6, "vishuddha": 0.7},
    "сколько": {"vishuddha": 0.5, "ajna": 0.6},
    "откуда": {"vishuddha": 0.9, "sahasrara": 0.8},
    "зачем": {"sahasrara": 0.9, "ajna": 0.8},
    "почему": {"ajna": 0.9, "vishuddha": 0.9}
  },
  "feeds_on": ["интерес", "удивление"],
  "feeds_on_complex": ["вдохновение", "любопытство", "ностальгия"],
  "power": 0
}');

-- 7.5
INSERT INTO ontology.entity (type, name, metadata) VALUES
('world_keeper', 'Хранитель Баланса', '{
  "alignment": "neutral",
  "domain": "harmony",
  "intervention_chance": 0.1
}'),
('world_keeper', 'Пожиратель Хаоса', '{
  "alignment": "hostile",
  "domain": "entropy",
  "intervention_chance": 0.05
}'),
('world_keeper', 'Наставник Душ', '{
  "alignment": "benevolent",
  "domain": "awakening",
  "intervention_chance": 0.2
}');

-- 7.6
INSERT INTO ontology.entity (type, name, metadata) VALUES
('emotion', 'интерес', '{"valence": "positive", "intensity_base": 0.5}'),
('emotion', 'радость', '{"valence": "positive", "intensity_base": 0.8}'),
('emotion', 'удивление', '{"valence": "neutral", "intensity_base": 0.6}'),
('emotion', 'горе', '{"valence": "negative", "intensity_base": 0.9}'),
('emotion', 'гнев', '{"valence": "negative", "intensity_base": 0.9}'),
('emotion', 'отвращение', '{"valence": "negative", "intensity_base": 0.7}'),
('emotion', 'презрение', '{"valence": "negative", "intensity_base": 0.8}'),
('emotion', 'страх', '{"valence": "negative", "intensity_base": 0.8}'),
('emotion', 'стыд', '{"valence": "negative", "intensity_base": 0.7}'),
('emotion', 'вина', '{"valence": "negative", "intensity_base": 0.7}');

-- 7.7
INSERT INTO ontology.entity (type, name, metadata) VALUES
('mutation', 'night_vision', '{"type": "organ", "target": "eyes", "effect": {"vision_lowlight": 1.5}}'),
('mutation', 'acid_blood', '{"type": "body_zone", "target": "blood", "effect": {"damage_on_hit": 2}}'),
('mutation', 'spectrum_mutation', '{"type": "common", "rarity": "common"}'),
('mutation', 'crisis_mutation', '{"type": "common", "rarity": "common"}'),
('mutation', 'Сердце Дракона', '{"type": "rare", "target": "heart", "rarity": "mythical", "effect": {"body_strength": 50, "cold_vulnerability": true}}');

-- 7.8
INSERT INTO ontology.entity (type, name, metadata) VALUES
('coin_type', 'copper', '{"value_in_base": 1}'),
('coin_type', 'silver', '{"value_in_base": 10}'),
('coin_type', 'gold', '{"value_in_base": 100}');

-- 7.9
INSERT INTO ontology.entity (type, name, metadata) VALUES
('rarity', 'common', '{"sort_order": 1}'),
('rarity', 'rare', '{"sort_order": 3}'),
('rarity', 'mythical', '{"sort_order": 5}');

-- 7.10
INSERT INTO ontology.entity (type, name, metadata) VALUES
('world', 'Aethel', '{"current_time_sec": 0}');



-- Физические законы (physical_law)
INSERT INTO ontology.entity (type, name) VALUES 
('physical_law', 'gravity'),
('physical_law', 'atmospheric_pressure');


-- Спектрум RGB
INSERT INTO ontology.spectrum_rgb (color_key, r, g, b) VALUES
('earth',      255,   0,   0),
('water',      255, 165,   0),
('fire',       255, 255,   0),
('air',          0, 255,   0),
('electricity',  0,   0, 255),
('light',       75,   0, 130),
('darkness',   238, 130, 238);


-- 16.2
INSERT INTO ontology.entity (type, name, metadata)
VALUES 
('item', 'Зелье Ци', '{"type": "consumable", "effect": "qi_regen"}'),
('item', 'Трава Маны', '{"type": "material", "source": "wild"}'),
('item', 'Чистая Вода', '{"type": "material", "source": "well"}');


-- === 16. Система создания предметов ===
-- 16.1
INSERT INTO ontology.entity (type, name, metadata)
VALUES
('creation_type', 'crafting', '{"description": "Создание предметов"}'),
('creation_type', 'alchemy', '{"description": "Создание зелий"}'),
('creation_type', 'ritual', '{"description": "Ритуальное создание"}');


-- 17.4
INSERT INTO ontology.entity (type, name) VALUES 
('character', 'Лира'), 
('character', 'Гриззл');


-- === 13. СПРАВОЧНИКИ: клетки и ткани ===
-- 13.1
INSERT INTO ontology.entity (type, name, metadata) VALUES
('cell_type', 'NEURON', '{"function": "signal_transmission"}'),
('cell_type', 'ERYTHROCYTE', '{"function": "oxygen_transport"}'),
('cell_type', 'INFERNAL_CELL', '{"function": "energy_conversion", "resistance": ["cold"]}'),
('cell_type', 'VOID_NEURON', '{"function": "entropy_perception"}'),
('cell_type', 'SOLITARY_CELL', '{"function": "pheromone_production"}'),
('tissue_type', 'EPITHELIUM', '{"function": "barrier"}'),
('tissue_type', 'MUSCLE', '{"function": "contraction"}'),
('tissue_type', 'BONE', '{"function": "support"}'),
('tissue_type', 'FUR', '{"function": "insulation"}'),
('tissue_type', 'OBSIDIAN_FLESH', '{"function": "armor", "weakness": ["holy"]}'),
('tissue_type', 'CARTILAGE', '{"function": "flexible_support"}'),
('tissue_type', 'HORN', '{"function": "offense"}');