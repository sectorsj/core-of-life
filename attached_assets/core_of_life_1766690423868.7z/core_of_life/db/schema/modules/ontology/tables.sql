CREATE TABLE ontology.entity (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type VARCHAR(50) NOT NULL,
    name VARCHAR(255),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    metadata JSONB,
    age INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'alive',
    timeline TEXT DEFAULT 'present'
);

CREATE TABLE ontology.relation (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    subject_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    predicate VARCHAR(60) NOT NULL,
    object_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    confidence FLOAT DEFAULT 1.0 CHECK (confidence BETWEEN 0 AND 1),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(subject_id, predicate, object_id)
);

CREATE TABLE ontology.effect (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    target_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    domain VARCHAR(30) NOT NULL,
    effect_type VARCHAR(60) NOT NULL,
    magnitude FLOAT NOT NULL DEFAULT 1.0,
    duration_sec INT,
    operation VARCHAR(10) NOT NULL DEFAULT 'add',
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ
);

CREATE TABLE ontology.attribute (
    entity_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    domain VARCHAR(30) NOT NULL,
    key VARCHAR(60) NOT NULL,
    base_value FLOAT NOT NULL,
    current_value FLOAT NOT NULL,
    last_updated TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (entity_id, domain, key)
);