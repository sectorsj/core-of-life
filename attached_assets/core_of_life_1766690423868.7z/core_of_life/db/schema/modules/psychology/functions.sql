-- 18.21 Обнаружение сложной эмоции
CREATE OR REPLACE FUNCTION ontology.detect_complex_emotion(p_character_id UUID)
RETURNS TEXT AS $$
DECLARE
    active_emotions JSONB := '{}';
    recipe RECORD;
    best_match TEXT := NULL;
    best_score FLOAT := 0;
    score FLOAT;
    emotion_name TEXT;
    intensity FLOAT;
BEGIN
    FOR emotion_name, intensity IN
        SELECT e.name, ae.intensity
        FROM ontology.active_emotion ae
        JOIN ontology.entity e ON ae.emotion_id = e.id
        WHERE ae.character_id = p_character_id
          AND ae.expires_at > NOW()
    LOOP
        active_emotions := jsonb_set(active_emotions, ARRAY[emotion_name], to_jsonb(intensity));
    END LOOP;
    IF jsonb_typeof(active_emotions) = 'null' OR jsonb_length(active_emotions) = 0 THEN
        RETURN NULL;
    END IF;
    FOR recipe IN
        SELECT name, components
        FROM ontology.emotion_recipe
    LOOP
        score := 0;
        FOR emotion_name IN SELECT jsonb_object_keys(recipe.components) LOOP
            IF active_emotions ? emotion_name THEN
                score := score + LEAST(
                    (active_emotions->>emotion_name)::FLOAT,
                    (recipe.components->>emotion_name)::FLOAT
                );
            END IF;
        END LOOP;
        score := score / jsonb_length(recipe.components);
        IF score > best_score AND score > 0.5 THEN
            best_score := score;
            best_match := recipe.name;
        END IF;
    END LOOP;
    RETURN best_match;
END;
$$ LANGUAGE plpgsql;


-- 18.22 Механизм захвата внимания
CREATE OR REPLACE FUNCTION ontology.check_attention_capture(p_character_id UUID)
RETURNS VOID AS $$
DECLARE
    complex_emotion TEXT;
    hook_question TEXT;
    chakra_name TEXT;
    openness FLOAT;
    vulnerability FLOAT;
    random_roll FLOAT;
BEGIN
    complex_emotion := ontology.detect_complex_emotion(p_character_id);
    IF complex_emotion IS NULL THEN RETURN; END IF;
    FOR hook_question IN
        SELECT DISTINCT jsonb_array_elements_text(e.metadata->'hooks')
        FROM ontology.entity e
        WHERE e.type = 'egregor'
          AND (
              e.metadata->'feeds_on_complex' ? complex_emotion
          )
    LOOP
        FOR chakra_name IN VALUES 
            ('muladhara'), ('svadhisthana'), ('manipura'),
            ('anahata'), ('vishuddha'), ('ajna'), ('sahasrara')
        LOOP
            SELECT current_value INTO openness
            FROM ontology.attribute
            WHERE entity_id = p_character_id
              AND domain = 'metaphysics'
              AND key = 'chakra_' || chakra_name || '_openness';
            openness := COALESCE(openness, 0.01);
            IF openness < 30.0 THEN
                vulnerability := 1.0 - (openness / 30.0);
            ELSIF openness < 70.0 THEN
                vulnerability := 0.3;
            ELSE
                vulnerability := 0.05;
            END IF;
            random_roll := random();
            IF random_roll < vulnerability THEN
                INSERT INTO ontology.notification (
                    character_id, title, message, action_required, source_id
                ) VALUES (
                    p_character_id,
                    'Ваше внимание было захвачено',
                    'Вы чувствуете ' || complex_emotion || '. ' || INITCAP(hook_question) || '?',
                    true,
                    (SELECT id FROM ontology.entity WHERE type = 'egregor' AND metadata->'feeds_on_complex' ? complex_emotion LIMIT 1)
                );
                RETURN;
            END IF;
        END LOOP;
    END LOOP;
END;
$$ LANGUAGE plpgsql;


-- 18.13 Внутренний конфликт
CREATE OR REPLACE FUNCTION ontology.apply_internal_conflict(
    p_character_id UUID,
    p_key1 TEXT,
    p_key2 TEXT DEFAULT NULL
)
RETURNS VOID AS $$
DECLARE
    need_attr TEXT;
    chakra_name TEXT;
BEGIN
    UPDATE ontology.attribute
    SET current_value = GREATEST(0, current_value - 10)
    WHERE entity_id = p_character_id AND domain = 'anthroposphere' AND key = 'willpower';
    IF p_key1 = 'duty' OR p_key2 = 'duty' THEN
        chakra_name := 'svadhisthana';
        need_attr := 'need_safety';
    ELSIF p_key1 = 'sacrifice' OR p_key2 = 'sacrifice' THEN
        chakra_name := 'anahata';
        need_attr := 'need_esteem';
    ELSE
        chakra_name := 'muladhara';
        need_attr := 'need_physiology';
    END IF;
    UPDATE ontology.attribute
    SET current_value = GREATEST(0, current_value - 15)
    WHERE entity_id = p_character_id AND domain = 'metaphysics' AND key = need_attr;
    UPDATE ontology.attribute
    SET current_value = GREATEST(0.01, current_value - 15.0)
    WHERE entity_id = p_character_id AND domain = 'metaphysics' AND key = 'chakra_' || chakra_name || '_openness';
    IF random() < 0.1 THEN
        INSERT INTO ontology.relation (subject_id, predicate, object_id)
        SELECT p_character_id, 'has_mutation', id
        FROM ontology.entity
        WHERE type = 'mutation' AND name = 'anxiety'
        ON CONFLICT DO NOTHING;
    END IF;
END;
$$ LANGUAGE plpgsql;


-- 18.12 Проверка приоритета
CREATE OR REPLACE FUNCTION ontology.check_worldview_priority(
    p_character_id UUID,
    p_key1 TEXT,
    p_key2 TEXT DEFAULT NULL,
    p_difficulty INT DEFAULT 15
)
RETURNS TABLE (
    roll INT,
    modifier INT,
    total INT,
    success BOOLEAN,
    recommended_action TEXT
) AS $$
DECLARE
    priority1 FLOAT := 0;
    priority2 FLOAT := 0;
    modifier_val INT;
    roll_val INT;
    total_val INT;
    success_val BOOLEAN;
BEGIN
    SELECT COALESCE(current_value, 0) INTO priority1
    FROM ontology.attribute
    WHERE entity_id = p_character_id AND domain = 'anthroposphere' AND key = 'worldview_' || p_key1;
    IF p_key2 IS NOT NULL THEN
        SELECT COALESCE(current_value, 0) INTO priority2
        FROM ontology.attribute
        WHERE entity_id = p_character_id AND domain = 'anthroposphere' AND key = 'worldview_' || p_key2;
    END IF;
    modifier_val := ((priority1 + priority2) / 10)::INT;
    roll_val := (random() * 20 + 1)::INT;
    total_val := roll_val + modifier_val;
    success_val := total_val >= p_difficulty;
    recommended_action := CASE WHEN success_val THEN 'follow_values' ELSE 'act_against_values' END;
    RETURN QUERY SELECT roll_val, modifier_val, total_val, success_val, recommended_action;
END;
$$ LANGUAGE plpgsql;