-- 9.2
CREATE INDEX idx_active_emotion_char ON ontology.active_emotion(character_id);

-- 9.3
CREATE INDEX idx_active_emotion_expires ON ontology.active_emotion(expires_at);
