-- Рецепты сложных эмоций
CREATE TABLE ontology.emotion_recipe (
    name TEXT PRIMARY KEY,
    components JSONB NOT NULL,
    valence TEXT NOT NULL,
    description TEXT
);

-- Активные эмоции
CREATE TABLE ontology.active_emotion (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    character_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    emotion_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    intensity FLOAT NOT NULL DEFAULT 1.0 CHECK (intensity BETWEEN 0 AND 1),
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);