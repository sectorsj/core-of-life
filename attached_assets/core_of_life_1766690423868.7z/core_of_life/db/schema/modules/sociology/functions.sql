-- 18.29 Генерация речи
CREATE OR REPLACE FUNCTION ontology.generate_utterance(
    p_speaker_id UUID,
    p_target_id UUID
)
RETURNS TEXT AS $$
DECLARE
    utterance TEXT;
BEGIN
    SELECT text_template INTO utterance
    FROM ontology.utterance_chain
    WHERE speaker_id = p_speaker_id AND target_id = p_target_id
    ORDER BY random()
    LIMIT 1;
    RETURN COALESCE(utterance, '...');
END;
$$ LANGUAGE plpgsql;


