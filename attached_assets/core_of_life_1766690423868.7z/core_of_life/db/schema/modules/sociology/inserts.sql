-- 17.5
INSERT INTO ontology.utterance_chain (speaker_id, target_id, chain, text_template)
VALUES (
    (SELECT id FROM ontology.entity WHERE name = 'Лира'),
    (SELECT id FROM ontology.entity WHERE name = 'Гриззл'),
    '[{"type": "W", "key": "duty", "weight": 0.8},
      {"type": "N", "key": "safety", "weight": 0.9},
      {"type": "E", "key": "fear", "weight": 0.7}]',
    'Я боюсь защищать, потому что не достоин'
);