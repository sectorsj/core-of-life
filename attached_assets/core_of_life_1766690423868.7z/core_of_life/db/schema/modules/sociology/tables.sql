-- Таблица речевой цепочки
CREATE TABLE ontology.utterance_chain (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    speaker_id UUID NOT NULL REFERENCES ontology.entity(id),
    target_id UUID NOT NULL REFERENCES ontology.entity(id),
    chain JSONB NOT NULL,
    text_template TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);