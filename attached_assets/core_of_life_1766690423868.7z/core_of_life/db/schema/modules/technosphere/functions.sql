-- 18.27 Создание предмета
CREATE OR REPLACE FUNCTION ontology.create_item(
    p_character_id UUID,
    p_recipe_id UUID
)
RETURNS TEXT AS $$
DECLARE
    recipe RECORD;
    chakra_openness FLOAT;
    material_id UUID;
    required_amount INT;
    current_amount INT;
BEGIN
    SELECT * INTO recipe FROM ontology.creation_recipe WHERE id = p_recipe_id;
    IF NOT FOUND THEN RETURN 'recipe_not_found'; END IF;
    SELECT current_value INTO chakra_openness
    FROM ontology.attribute
    WHERE entity_id = p_character_id
      AND domain = 'metaphysics'
      AND key = 'chakra_' || recipe.required_chakra || '_openness';
    IF COALESCE(chakra_openness, 0) < recipe.required_openness THEN
        RETURN 'chakra_not_open_enough';
    END IF;
    FOR material_id, required_amount IN
        SELECT key::UUID, value::INT FROM jsonb_each(recipe.materials)
    LOOP
        SELECT COUNT(*) INTO current_amount
        FROM ontology.relation
        WHERE subject_id = p_character_id
          AND predicate = 'possesses'
          AND object_id = material_id;
        IF current_amount < required_amount THEN
            RETURN 'insufficient_materials';
        END IF;
    END LOOP;
    INSERT INTO ontology.relation (subject_id, predicate, object_id)
    VALUES (p_character_id, 'possesses', recipe.output_item_id);
    DELETE FROM ontology.relation
    WHERE subject_id = p_character_id
      AND predicate = 'possesses'
      AND object_id IN (SELECT key::UUID FROM jsonb_each(recipe.materials));
    RETURN 'success';
END;
$$ LANGUAGE plpgsql;


