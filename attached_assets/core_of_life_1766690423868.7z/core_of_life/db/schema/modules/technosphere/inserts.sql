-- 16.4
INSERT INTO ontology.creation_recipe (
    name, output_item_id, creation_type_id, required_chakra, required_openness, materials
) VALUES (
    'Зелье Ци',
    (SELECT id FROM ontology.entity WHERE name = 'Зелье Ци'),
    (SELECT id FROM ontology.entity WHERE name = 'alchemy'),
    'anahata',
    30.0,
    jsonb_build_object(
        (SELECT id FROM ontology.entity WHERE name = 'Трава Маны'), 3,
        (SELECT id FROM ontology.entity WHERE name = 'Чистая Вода'), 1
    )
);


