-- 16.3
CREATE TABLE ontology.creation_recipe (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    output_item_id UUID NOT NULL REFERENCES ontology.entity(id),
    creation_type_id UUID NOT NULL REFERENCES ontology.entity(id),
    required_chakra TEXT NOT NULL,
    required_openness FLOAT NOT NULL DEFAULT 30.0,
    materials JSONB NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- === 5. ТЕХНОСФЕРА ===
-- 5.1
CREATE TABLE technosphere.coin_purse (
    character_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    coin_type_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    amount INT NOT NULL DEFAULT 0 CHECK (amount >= 0),
    PRIMARY KEY (character_id, coin_type_id)
);