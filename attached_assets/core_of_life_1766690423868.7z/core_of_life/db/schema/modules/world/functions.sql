-- 18.33 Старение персонажей
CREATE OR REPLACE FUNCTION ontology.age_all_characters()
RETURNS VOID AS $$
BEGIN
    UPDATE ontology.entity
    SET age = age + 1
    WHERE type = 'character' AND status = 'alive';
END;
$$ LANGUAGE plpgsql;

-- 18.34 Проверка социальных связей
CREATE OR REPLACE FUNCTION ontology.check_social_bonds()
RETURNS VOID AS $$
DECLARE
    pair RECORD;
BEGIN
    FOR pair IN
        SELECT r1.subject_id AS c1, r2.subject_id AS c2
        FROM ontology.relation r1
        JOIN ontology.relation r2 ON r1.object_id = r2.object_id
        WHERE r1.predicate = 'located_in'
          AND r2.predicate = 'located_in'
          AND r1.subject_id < r2.subject_id
          AND NOT EXISTS (
              SELECT 1 FROM ontology.relation
              WHERE subject_id = r1.subject_id AND object_id = r2.subject_id AND predicate = 'knows'
          )
    LOOP
        IF random() < 0.05 THEN
            INSERT INTO ontology.relation (subject_id, predicate, object_id)
            VALUES (pair.c1, 'knows', pair.c2), (pair.c2, 'knows', pair.c1);
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql;


-- 18.31 Обновление погоды
CREATE OR REPLACE FUNCTION ontology.update_weather(p_region_id UUID)
RETURNS VOID AS $$
DECLARE
    spectrum JSONB; dominant_color TEXT; max_intensity FLOAT := 0; color TEXT; intensity FLOAT; new_weather TEXT;
BEGIN
    SELECT metadata->'spectrum' INTO spectrum FROM ontology.entity WHERE id = p_region_id;
    IF spectrum IS NULL THEN RETURN; END IF;
    FOR color IN SELECT jsonb_object_keys(spectrum) LOOP
        intensity := (spectrum->>color)::FLOAT;
        IF intensity > max_intensity THEN
            max_intensity := intensity;
            dominant_color := color;
        END IF;
    END LOOP;
    CASE dominant_color
        WHEN 'earth' THEN new_weather := 'dust_storm';
        WHEN 'fire' THEN new_weather := 'heat_wave';
        WHEN 'air' THEN new_weather := 'gentle_breeze';
        WHEN 'darkness' THEN new_weather := 'reality_rift';
        ELSE new_weather := 'clear';
    END CASE;
    UPDATE ontology.entity
    SET metadata = jsonb_set(COALESCE(metadata, '{}'), '{current_weather}', to_jsonb(new_weather))
    WHERE id = p_region_id;
END;
$$ LANGUAGE plpgsql;


-- 18.32 Обновление эгрегора
CREATE OR REPLACE FUNCTION ontology.update_egregor(p_egregor_id UUID)
RETURNS VOID AS $$
DECLARE
    total_power FLOAT := 0;
    follower RECORD;
BEGIN
    FOR follower IN
        SELECT r.subject_id
        FROM ontology.relation r
        WHERE r.object_id = p_egregor_id AND r.predicate = 'connected_to_egregor'
    LOOP
        total_power := total_power + 1;
    END LOOP;
    UPDATE ontology.entity
    SET metadata = jsonb_set(metadata, '{power}', to_jsonb(total_power))
    WHERE id = p_egregor_id;
END;
$$ LANGUAGE plpgsql;


-- 18.35 World tick
CREATE OR REPLACE FUNCTION ontology.world_tick()
RETURNS VOID AS $$
DECLARE
    region RECORD;
    pair RECORD;
    child_id UUID;
    npc RECORD;
BEGIN
    PERFORM ontology.age_all_characters();
    FOR pair IN
        SELECT r1.subject_id AS parent1, r2.subject_id AS parent2, r1.object_id AS region
        FROM ontology.relation r1
        JOIN ontology.relation r2 ON r1.object_id = r2.object_id
        WHERE r1.predicate = 'located_in'
          AND r2.predicate = 'located_in'
          AND r1.subject_id != r2.subject_id
          AND EXISTS (SELECT 1 FROM ontology.entity WHERE id = r1.subject_id AND age BETWEEN 18 AND 50 AND status = 'alive')
          AND EXISTS (SELECT 1 FROM ontology.entity WHERE id = r2.subject_id AND age BETWEEN 18 AND 50 AND status = 'alive')
    LOOP
        IF random() < 0.01 THEN
            child_id := ontology.create_child(pair.parent1, pair.parent2, 'Ребёнок');
            INSERT INTO ontology.relation (subject_id, predicate, object_id)
            VALUES (child_id, 'located_in', pair.region);
        END IF;
    END LOOP;
    FOR npc IN
        SELECT id, age
        FROM ontology.entity
        WHERE type = 'character'
          AND status = 'alive'
          AND (
              age > 80 OR
              (SELECT current_value FROM ontology.attribute WHERE entity_id = id AND domain = 'biology' AND key = 'body_strength') < 10
          )
    LOOP
        UPDATE ontology.entity SET status = 'dead' WHERE id = npc.id;
    END LOOP;
    FOR npc IN
        SELECT id FROM ontology.entity WHERE type = 'character' AND status = 'alive'
    LOOP
        PERFORM ontology.check_attention_capture(npc.id);
        PERFORM ontology.check_for_mutation(npc.id);
        PERFORM ontology.check_social_bonds();
        PERFORM ontology.apply_chakra_effects(npc.id);
        PERFORM biology.use_movement_pattern(npc.id, 'basic_strike'); -- пример боевого паттерна
    END LOOP;
    FOR region IN SELECT id FROM ontology.entity WHERE type = 'region' LOOP
        PERFORM ontology.update_weather(region.id);
    END LOOP;
    FOR region IN SELECT id FROM ontology.entity WHERE type = 'egregor' LOOP
        PERFORM ontology.update_egregor(region.id);
    END LOOP;
    UPDATE ontology.entity
    SET metadata = jsonb_set(metadata, '{current_time_sec}', to_jsonb((metadata->>'current_time_sec')::INT + 86400))
    WHERE type = 'world';
END;
$$ LANGUAGE plpgsql;


-- 18.30 Генерация динамического квеста
CREATE OR REPLACE FUNCTION ontology.generate_dynamic_quest(
    p_character_id UUID,
    p_region_id UUID
)
RETURNS UUID AS $$
DECLARE
    quest_id UUID;
    region_spectrum JSONB;
    dominant_color TEXT;
    max_intensity FLOAT := 0;
    color TEXT;
    intensity FLOAT;
BEGIN
    SELECT metadata->'spectrum' INTO region_spectrum FROM ontology.entity WHERE id = p_region_id;
    FOR color IN SELECT jsonb_object_keys(region_spectrum) LOOP
        intensity := (region_spectrum->>color)::FLOAT;
        IF intensity > max_intensity THEN
            max_intensity := intensity;
            dominant_color := color;
        END IF;
    END LOOP;
    CASE dominant_color
        WHEN 'earth' THEN
            INSERT INTO ontology.entity (type, name, metadata)
            VALUES ('quest', 'Найти источник воды',
                '{"description": "В пустыне жажда убивает. Найди оазис.", "keys": ["survival"]}')
            RETURNING id INTO quest_id;
        WHEN 'air' THEN
            INSERT INTO ontology.entity (type, name, metadata)
            VALUES ('quest', 'Доставить лекарство старейшине',
                '{"description": "Старейшина болен. Спаси его!", "keys": ["duty", "sacrifice"], "tags": ["virtue_deed"]}')
            RETURNING id INTO quest_id;
        ELSE
            INSERT INTO ontology.entity (type, name, metadata)
            VALUES ('quest', 'Исследовать окрестности',
                '{"description": "Что скрывает эта земля?", "keys": ["curiosity"]}')
            RETURNING id INTO quest_id;
    END CASE;
    INSERT INTO ontology.relation (subject_id, predicate, object_id)
    VALUES (p_character_id, 'assigned_quest', quest_id);
    RETURN quest_id;
END;
$$ LANGUAGE plpgsql;


-- 18.28 Генерация сцены
CREATE OR REPLACE FUNCTION ontology.get_scene_for_event(
    p_event TEXT,
    p_chakra TEXT DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
    scene JSONB;
BEGIN
    SELECT jsonb_build_object(
        'trigger_event', trigger_event,
        'camera', camera,
        'effects', effects
    ) INTO scene
    FROM ontology.scene_template
    WHERE trigger_event = p_event
      AND (target_chakra IS NULL OR target_chakra = p_chakra)
    ORDER BY random()
    LIMIT 1;
    RETURN COALESCE(scene, '{}'::jsonb);
END;
$$ LANGUAGE plpgsql;