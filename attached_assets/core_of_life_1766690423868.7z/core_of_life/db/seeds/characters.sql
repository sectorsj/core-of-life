-- 1. Старый Воин (HUMANOID)
INSERT INTO ontology.entity (type, name, metadata) VALUES
('character', 'Борис', '{"genome": "HUMANOID|NEURON,ERYTHROCYTE|EPITHELIUM,MUSCLE,BONE|BRAIN,HEART,LUNGS,LIVER,SINEW|BLOOD,LYMPH|NERVOUS,CIRCULATORY,MUSCULAR|GGCC|ATAT|TTGG|CCAA|AATT|GGTT|CCTT"}');

SELECT biology.initialize_biology_from_genome(
    (SELECT id FROM ontology.entity WHERE name = 'Борис'),
    (SELECT metadata->>'genome' FROM ontology.entity WHERE name = 'Борис')
);

-- 2. Лекарь (HUMANOID)
INSERT INTO ontology.entity (type, name, metadata) VALUES
('character', 'Элла', '{"genome": "HUMANOID|NEURON,ERYTHROCYTE|EPITHELIUM,MUSCLE|BRAIN,HEART,LUNGS,KIDNEY|BLOOD,LYMPH|NERVOUS,CIRCULATORY,RENAL|AAAA|TTTT|GGGG|CCCC|AAAA|TTTT|GGGG"}');

SELECT biology.initialize_biology_from_genome(
    (SELECT id FROM ontology.entity WHERE name = 'Элла'),
    (SELECT metadata->>'genome' FROM ontology.entity WHERE name = 'Элла')
);

-- 3. Волк-воин (THERIAN)
INSERT INTO ontology.entity (type, name, metadata) VALUES
('character', 'Вулкан', '{"genome": "THERIAN|NEURON,ERYTHROCYTE,SOLITARY_CELL|FUR,MUSCLE,BONE,CARTILAGE|BRAIN,HEART,LUNGS,SCENT_GLAND,CLAWS|BLOOD,LYMPH|NERVOUS,CIRCULATORY,OLFACTORY|GCGC|ATAT|TTTT|GCGC|ACGT|TATA|CGCG"}');

SELECT biology.initialize_biology_from_genome(
    (SELECT id FROM ontology.entity WHERE name = 'Вулкан'),
    (SELECT metadata->>'genome' FROM ontology.entity WHERE name = 'Вулкан')
);

-- 4. Кошачья шпионка (THERIAN)
INSERT INTO ontology.entity (type, name, metadata) VALUES
('character', 'Нима', '{"genome": "THERIAN|NEURON,ERYTHROCYTE,SOLITARY_CELL|FUR,MUSCLE,BONE|BRAIN,HEART,LUNGS,SCENT_GLAND,EYES|BLOOD,LYMPH|NERVOUS,CIRCULATORY,OLFACTORY|AAAA|GGGG|TTTT|CCCC|GGGG|TTTT|AAAA"}');

SELECT biology.initialize_biology_from_genome(
    (SELECT id FROM ontology.entity WHERE name = 'Нима'),
    (SELECT metadata->>'genome' FROM ontology.entity WHERE name = 'Нима')
);

-- 5. Демон Боли (DEMONOID)
INSERT INTO ontology.entity (type, name, metadata) VALUES
('character', 'Моргат', '{"genome": "DEMONOID|INFERNAL_CELL,VOID_NEURON|OBSIDIAN_FLESH,HORN|INFERNAL_CORE,VOID_BRAIN,CLAW,HEART|ICHOR|ETHEREAL,COMBUSTION,PAIN|CCCC|TTTT|GGGG|AAAA|TTTT|GGGG|CCCC"}');

SELECT biology.initialize_biology_from_genome(
    (SELECT id FROM ontology.entity WHERE name = 'Моргат'),
    (SELECT metadata->>'genome' FROM ontology.entity WHERE name = 'Моргат')
);

-- 6. Ангел-хранитель (CELESTIAL)
INSERT INTO ontology.entity (type, name, metadata) VALUES
('character', 'Серафина', '{"genome": "CELESTIAL|LUMINOUS_CELL,NEURON|FEATHER,MUSCLE|LUMINOUS_BRAIN,HEART,WINGS|STARLIGHT|CELESTIAL,ILLUMINATION|AAAA|AAAA|AAAA|GGGG|GGGG|GGGG|TTTT"}');

SELECT biology.initialize_biology_from_genome(
    (SELECT id FROM ontology.entity WHERE name = 'Серафина'),
    (SELECT metadata->>'genome' FROM ontology.entity WHERE name = 'Серафина')
);

-- 7. Зомби-боец (UNDEAD)
INSERT INTO ontology.entity (type, name, metadata) VALUES
('character', 'Грум', '{"genome": "UNDEAD|NECROTIC_CELL,VOID_NEURON|ROT_FLESH,BONE|NECROTIC_HEART,VOID_BRAIN|BLACK_ICHOR|ENTROPY,ROT|TTTT|TTTT|CCCC|CCCC|AAAA|AAAA|GGGG"}');

SELECT biology.initialize_biology_from_genome(
    (SELECT id FROM ontology.entity WHERE name = 'Грум'),
    (SELECT metadata->>'genome' FROM ontology.entity WHERE name = 'Грум')
);

-- 8. Женщина-гидра (HYBRID)
INSERT INTO ontology.entity (type, name, metadata) VALUES
('character', 'Медуза', '{"genome": "HYBRID|NEURON,ERYTHROCYTE,VENOM_CELL|SCALE,MUSCLE,BONE|BRAIN,HEART,LUNGS,POISON_GLAND|VENOM_BLOOD|CIRCULATORY,TOXIC|ATGC|CGAT|GCTA|TGCA|ATGC|CGAT|GCTA"}');

SELECT biology.initialize_biology_from_genome(
    (SELECT id FROM ontology.entity WHERE name = 'Медуза'),
    (SELECT metadata->>'genome' FROM ontology.entity WHERE name = 'Медуза')
);

-- 9. Голем (CONSTRUCT)
INSERT INTO ontology.entity (type, name, metadata) VALUES
('character', 'Камень', '{"genome": "CONSTRUCT|CRYSTAL_CORE,LOGIC_ENGINE|STONE,METAL|CRYSTAL_CORE,LOGIC_ENGINE|ETHER_OIL|MECHANICAL,GEOMANTIC|GGGG|CCCC|TTTT|AAAA|TTTT|AAAA|CCCC"}');

SELECT biology.initialize_biology_from_genome(
    (SELECT id FROM ontology.entity WHERE name = 'Камень'),
    (SELECT metadata->>'genome' FROM ontology.entity WHERE name = 'Камень')
);

-- 10. Ребёнок-гибрид (HUMANOID x THERIAN)
-- Создадим его как потомка Бориса и Нимы
SELECT ontology.create_child(
    (SELECT id FROM ontology.entity WHERE name = 'Борис'),
    (SELECT id FROM ontology.entity WHERE name = 'Нима'),
    'Люк'
);