-- ПОЛНЫЙ SQL-СКРИПТ: «Ядро жизни» — v3.0 (Саморазвивающаяся вселенная)
-- === 0. Подготовка расширений ===
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- === 1. Схемы ===
CREATE SCHEMA IF NOT EXISTS ontology;
CREATE SCHEMA IF NOT EXISTS auth;
CREATE SCHEMA IF NOT EXISTS physics;
CREATE SCHEMA IF NOT EXISTS metaphysics;
CREATE SCHEMA IF NOT EXISTS chemistry;
CREATE SCHEMA IF NOT EXISTS geography;
CREATE SCHEMA IF NOT EXISTS geometry;
CREATE SCHEMA IF NOT EXISTS biology;
CREATE SCHEMA IF NOT EXISTS noosphere;
CREATE SCHEMA IF NOT EXISTS anthroposphere;
CREATE SCHEMA IF NOT EXISTS technosphere;

-- === 2. Онтологическое ядро ===
CREATE TABLE ontology.entity (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type VARCHAR(50) NOT NULL,
    name VARCHAR(255),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    metadata JSONB,
    age INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'alive' -- alive, dying, dead
);

CREATE TABLE ontology.relation (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    subject_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    predicate VARCHAR(60) NOT NULL,
    object_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    confidence FLOAT DEFAULT 1.0 CHECK (confidence BETWEEN 0 AND 1),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(subject_id, predicate, object_id)
);

-- УДАЛЕН СТОЛБЕЦ expires_at из-за ошибки синтаксиса в PostgreSQL
CREATE TABLE ontology.effect (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    target_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    domain VARCHAR(30) NOT NULL,
    effect_type VARCHAR(60) NOT NULL,
    magnitude FLOAT NOT NULL DEFAULT 1.0,
    duration_sec INT,
    operation VARCHAR(10) NOT NULL DEFAULT 'add',
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT chk_effect_operation CHECK (operation IN ('add', 'multiply', 'set'))
);

CREATE TABLE ontology.attribute (
    entity_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    domain VARCHAR(30) NOT NULL,
    key VARCHAR(60) NOT NULL,
    base_value FLOAT NOT NULL,
    current_value FLOAT NOT NULL,
    last_updated TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (entity_id, domain, key)
);

-- === 3. AUTH ===
CREATE TABLE auth.account (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- === 4. ГЕОГРАФИЯ ===
CREATE TABLE geography.region_vertex (
    id SERIAL PRIMARY KEY,
    region_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    elevation DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    vertex_order INT NOT NULL,
    UNIQUE(region_id, vertex_order)
);

-- === 5. ТЕХНОСФЕРА ===
CREATE TABLE technosphere.coin_purse (
    character_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    coin_type_id UUID NOT NULL REFERENCES ontology.entity(id) ON DELETE CASCADE,
    amount INT NOT NULL DEFAULT 0 CHECK (amount >= 0),
    PRIMARY KEY (character_id, coin_type_id)
);

-- === 6. Справочник цветов Спектрума (RGB) ===
CREATE TABLE ontology.spectrum_rgb (
    color_key TEXT PRIMARY KEY,
    r INT, g INT, b INT
);

INSERT INTO ontology.spectrum_rgb (color_key, r, g, b) VALUES
('earth',      255,   0,   0),  -- красный
('water',      255, 165,   0),  -- оранжевый
('fire',       255, 255,   0),  -- жёлтый
('air',          0, 255,   0),  -- зелёный
('electricity',  0,   0, 255),  -- голубой
('light',       75,   0, 130),  -- индиго
('darkness',   238, 130, 238);  -- фиолетовый

-- === 7. Начальные сущности ===

-- Физика
INSERT INTO ontology.entity (type, name) VALUES 
('physical_law', 'gravity'),
('physical_law', 'atmospheric_pressure');

-- Чакры = Потребности по Маслоу
INSERT INTO ontology.entity (type, name, metadata) VALUES
('chakra', 'muladhara',   '{"need": "physiology", "spectrum": "earth"}'),
('chakra', 'svadhisthana', '{"need": "safety", "spectrum": "water"}'),
('chakra', 'manipura',    '{"need": "belonging", "spectrum": "fire"}'),
('chakra', 'anahata',     '{"need": "esteem", "spectrum": "air"}'),
('chakra', 'vishuddha',   '{"need": "cognition", "spectrum": "electricity"}'),
('chakra', 'ajna',        '{"need": "aesthetics", "spectrum": "light"}'),
('chakra', 'sahasrara',   '{"need": "self_actualization", "spectrum": "darkness"}');

-- Ключи мировоззрения
INSERT INTO ontology.entity (type, name) VALUES
('worldview_key', 'duty'),
('worldview_key', 'freedom'),
('worldview_key', 'sacrifice'),
('worldview_key', 'power'),
('worldview_key', 'truth');

-- Маятники-Эгрегоры
INSERT INTO ontology.entity (type, name, metadata) VALUES
('egregor', 'Война', '{
  "description": "Маятник конфликта",
  "hooks": ["зачем", "куда", "кто"],
  "energy_type": "conflict",
  "power": 0
}'),
('egregor', 'Семья', '{
  "description": "Маятник родственных связей",
  "hooks": ["зачем", "кто", "почему"],
  "energy_type": "attachment",
  "power": 0
}'),
('egregor', 'Знание', '{
  "description": "Маятник истины",
  "hooks": ["почему", "что", "зачем"],
  "energy_type": "curiosity",
  "power": 0
}');

-- Хранители Ядра
INSERT INTO ontology.entity (type, name, metadata) VALUES
('world_keeper', 'Хранитель Баланса', '{
  "alignment": "neutral",
  "domain": "harmony",
  "intervention_chance": 0.1
}'),
('world_keeper', 'Пожиратель Хаоса', '{
  "alignment": "hostile",
  "domain": "entropy",
  "intervention_chance": 0.05
}'),
('world_keeper', 'Наставник Душ', '{
  "alignment": "benevolent",
  "domain": "awakening",
  "intervention_chance": 0.2
}');

-- Мутации
INSERT INTO ontology.entity (type, name, metadata) VALUES
('mutation', 'night_vision', '{"type": "organ", "target": "eyes", "effect": {"vision_lowlight": 1.5}}'),
('mutation', 'acid_blood', '{"type": "body_zone", "target": "blood", "effect": {"damage_on_hit": 2}}'),
('mutation', 'spectrum_mutation', '{"type": "common", "rarity": "common"}'),
('mutation', 'crisis_mutation', '{"type": "common", "rarity": "common"}'),
('mutation', 'Сердце Дракона', '{"type": "rare", "target": "heart", "rarity": "mythical", "effect": {"body_strength": 50, "cold_vulnerability": true}}');

-- Монеты
INSERT INTO ontology.entity (type, name, metadata) VALUES
('coin_type', 'copper', '{"value_in_base": 1}'),
('coin_type', 'silver', '{"value_in_base": 10}'),
('coin_type', 'gold', '{"value_in_base": 100}');

-- Редкость
INSERT INTO ontology.entity (type, name, metadata) VALUES
('rarity', 'common', '{"sort_order": 1}'),
('rarity', 'rare', '{"sort_order": 3}'),
('rarity', 'mythical', '{"sort_order": 5}');

-- Мир
INSERT INTO ontology.entity (type, name, metadata) VALUES
('world', 'Aethel', '{"current_time_sec": 0}');

-- === 8. ФУНКЦИИ ===

-- Вспомогательная функция: вычисление expires_at (вручную)
CREATE OR REPLACE FUNCTION ontology.get_effect_expires_at(created_at TIMESTAMPTZ, duration_sec INT)
RETURNS TIMESTAMPTZ AS $$
BEGIN
    IF duration_sec IS NULL THEN
        RETURN NULL;
    ELSE
        RETURN created_at + MAKE_INTERVAL(secs => duration_sec);
    END IF;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Парсинг effect_type
CREATE OR REPLACE FUNCTION ontology.parse_effect_type(effect_type TEXT, OUT domain TEXT, OUT key TEXT)
AS $$
BEGIN
    IF effect_type LIKE '%.%' THEN
        domain := split_part(effect_type, '.', 1);
        key := split_part(effect_type, '.', 2);
    ELSE
        domain := NULL;
        key := NULL;
    END IF;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Пересчёт атрибута (использует вычисляемый expires_at)
CREATE OR REPLACE FUNCTION ontology.recalculate_attribute(p_entity_id UUID, p_domain TEXT, p_key TEXT)
RETURNS VOID AS $$
DECLARE
    base_val FLOAT;
    final_val FLOAT;
    eff RECORD;
BEGIN
    SELECT base_value INTO base_val
    FROM ontology.attribute
    WHERE entity_id = p_entity_id AND domain = p_domain AND key = p_key;
    IF base_val IS NULL THEN RETURN; END IF;
    final_val := base_val;
    FOR eff IN
        SELECT e.magnitude, e.operation
        FROM ontology.effect e
        WHERE e.target_id = p_entity_id
          AND e.active = true
          AND (ontology.get_effect_expires_at(e.created_at, e.duration_sec) IS NULL OR ontology.get_effect_expires_at(e.created_at, e.duration_sec) > NOW())
          AND e.effect_type = p_domain || '.' || p_key
    LOOP
        CASE eff.operation
            WHEN 'add' THEN final_val := final_val + eff.magnitude;
            WHEN 'multiply' THEN final_val := final_val * eff.magnitude;
            WHEN 'set' THEN final_val := eff.magnitude;
        END CASE;
    END LOOP;
    UPDATE ontology.attribute
    SET current_value = final_val, last_updated = NOW()
    WHERE entity_id = p_entity_id AND domain = p_domain AND key = p_key;
END;
$$ LANGUAGE plpgsql;

-- Расчёт аффинити к стихиям из генома
CREATE OR REPLACE FUNCTION ontology.calculate_elemental_affinity(p_genome TEXT)
RETURNS JSONB AS $$
DECLARE
    affinities JSONB := '{
        "earth": 0, "water": 0, "fire": 0, "air": 0,
        "electricity": 0, "light": 0, "darkness": 0
    }';
    locus TEXT;
    score FLOAT;
    bases TEXT[] := ARRAY['earth', 'water', 'fire', 'air', 'electricity', 'light', 'darkness'];
    i INT;
BEGIN
    FOR i IN 1..7 LOOP
        locus := split_part(p_genome, '|', i);
        score := (
            (LENGTH(locus) - LENGTH(REPLACE(locus, 'G', ''))) * 1.5 +
            (LENGTH(locus) - LENGTH(REPLACE(locus, 'C', ''))) * 1.5 +
            (LENGTH(locus) - LENGTH(REPLACE(locus, 'A', ''))) * 1.0 +
            (LENGTH(locus) - LENGTH(REPLACE(locus, 'T', ''))) * 1.0
        );
        affinities := jsonb_set(affinities, ARRAY[bases[i]], to_jsonb(score));
    END LOOP;
    RETURN affinities;
END;
$$ LANGUAGE plpgsql;

-- Инициализация черт из генома
CREATE OR REPLACE FUNCTION ontology.initialize_traits_from_genome(p_character_id UUID, p_genome TEXT)
RETURNS VOID AS $$
DECLARE
    affinities JSONB;
    earth FLOAT; water FLOAT; fire FLOAT; air FLOAT;
    electricity FLOAT; light FLOAT; darkness FLOAT;
BEGIN
    affinities := ontology.calculate_elemental_affinity(p_genome);
    earth := (affinities->>'earth')::FLOAT;
    water := (affinities->>'water')::FLOAT;
    fire := (affinities->>'fire')::FLOAT;
    air := (affinities->>'air')::FLOAT;
    electricity := (affinities->>'electricity')::FLOAT;
    light := (affinities->>'light')::FLOAT;
    darkness := (affinities->>'darkness')::FLOAT;

    INSERT INTO ontology.attribute (entity_id, domain, key, base_value, current_value) VALUES
    (p_character_id, 'biology', 'body_strength', earth, earth),
    (p_character_id, 'anthroposphere', 'emotional_stability', water, water),
    (p_character_id, 'metaphysics', 'chakra_manipura_openness', LEAST(1.0, fire / 10.0), LEAST(1.0, fire / 10.0)),
    (p_character_id, 'metaphysics', 'chakra_anahata_openness', LEAST(1.0, air / 10.0), LEAST(1.0, air / 10.0)),
    (p_character_id, 'noosphere', 'mental_speed', electricity, electricity),
    (p_character_id, 'metaphysics', 'chakra_ajna_openness', LEAST(1.0, light / 10.0), LEAST(1.0, light / 10.0)),
    (p_character_id, 'metaphysics', 'chakra_sahasrara_openness', LEAST(1.0, darkness / 10.0), LEAST(1.0, darkness / 10.0));

    UPDATE ontology.entity
    SET metadata = jsonb_set(metadata, '{elemental_affinity}', affinities)
    WHERE id = p_character_id;
END;
$$ LANGUAGE plpgsql;

-- Создание ребёнка
CREATE OR REPLACE FUNCTION ontology.create_child(
    p_father_id UUID,
    p_mother_id UUID,
    p_name TEXT
)
RETURNS UUID AS $$
DECLARE
    child_id UUID;
    father_genome TEXT;
    mother_genome TEXT;
    child_genome TEXT := '';
    i INT;
    father_locus TEXT;
    mother_locus TEXT;
    child_locus TEXT;
    base1 CHAR(1);
    base2 CHAR(1);
    base3 CHAR(1);
    base4 CHAR(1);
BEGIN
    SELECT metadata->>'genome' INTO father_genome FROM ontology.entity WHERE id = p_father_id;
    SELECT metadata->>'genome' INTO mother_genome FROM ontology.entity WHERE id = p_mother_id;
    FOR i IN 1..7 LOOP
        father_locus := split_part(father_genome, '|', i);
        mother_locus := split_part(mother_genome, '|', i);
        base1 := CASE WHEN random() < 0.5 THEN substr(father_locus, 1, 1) ELSE substr(mother_locus, 1, 1) END;
        base2 := CASE WHEN random() < 0.5 THEN substr(father_locus, 2, 1) ELSE substr(mother_locus, 2, 1) END;
        base3 := CASE WHEN random() < 0.5 THEN substr(father_locus, 3, 1) ELSE substr(mother_locus, 3, 1) END;
        base4 := CASE WHEN random() < 0.5 THEN substr(father_locus, 4, 1) ELSE substr(mother_locus, 4, 1) END;
        child_locus := base1 || base2 || base3 || base4;
        IF i > 1 THEN child_genome := child_genome || '|'; END IF;
        child_genome := child_genome || child_locus;
    END LOOP;
    INSERT INTO ontology.entity (type, name, metadata, age, status)
    VALUES ('character', p_name, jsonb_build_object('genome', child_genome), 0, 'alive')
    RETURNING id INTO child_id;
    INSERT INTO ontology.relation (subject_id, predicate, object_id)
    VALUES (child_id, 'child_of', p_father_id), (child_id, 'child_of', p_mother_id);
    PERFORM ontology.initialize_traits_from_genome(child_id, child_genome);
    RETURN child_id;
END;
$$ LANGUAGE plpgsql;

-- Спектрум → RGB
CREATE OR REPLACE FUNCTION ontology.spectrum_to_rgb(spectrum JSONB)
RETURNS JSONB AS $$
DECLARE
    total_r INT := 0; total_g INT := 0; total_b INT := 0;
    color TEXT; intensity FLOAT; rgb RECORD;
BEGIN
    FOR color IN SELECT jsonb_object_keys(spectrum) LOOP
        intensity := GREATEST(0, LEAST(1, (spectrum->>color)::FLOAT));
        SELECT r, g, b INTO rgb FROM ontology.spectrum_rgb WHERE color_key = color;
        IF FOUND THEN
            total_r := total_r + (rgb.r * intensity)::INT;
            total_g := total_g + (rgb.g * intensity)::INT;
            total_b := total_b + (rgb.b * intensity)::INT;
        END IF;
    END LOOP;
    total_r := LEAST(255, total_r);
    total_g := LEAST(255, total_g);
    total_b := LEAST(255, total_b);
    RETURN jsonb_build_object('r', total_r, 'g', total_g, 'b', total_b);
END;
$$ LANGUAGE plpgsql;

-- Обновление ауры
CREATE OR REPLACE FUNCTION ontology.update_aura_rgb(p_character_id UUID)
RETURNS VOID AS $$
DECLARE
    spectrum JSONB;
BEGIN
    SELECT metadata->'spectrum' INTO spectrum FROM ontology.entity WHERE id = p_character_id;
    IF spectrum IS NULL THEN RETURN; END IF;
    UPDATE ontology.entity
    SET metadata = jsonb_set(COALESCE(metadata, '{}'), '{aura_rgb}', ontology.spectrum_to_rgb(spectrum))
    WHERE id = p_character_id;
END;
$$ LANGUAGE plpgsql;

-- Проверка приоритета
CREATE OR REPLACE FUNCTION ontology.check_worldview_priority(
    p_character_id UUID,
    p_key1 TEXT,
    p_key2 TEXT DEFAULT NULL,
    p_difficulty INT DEFAULT 15
)
RETURNS TABLE (
    roll INT,
    modifier INT,
    total INT,
    success BOOLEAN,
    recommended_action TEXT
) AS $$
DECLARE
    priority1 FLOAT := 0;
    priority2 FLOAT := 0;
    modifier_val INT;
    roll_val INT;
    total_val INT;
    success_val BOOLEAN;
BEGIN
    SELECT COALESCE(current_value, 0) INTO priority1
    FROM ontology.attribute
    WHERE entity_id = p_character_id AND domain = 'anthroposphere' AND key = 'worldview_' || p_key1;
    IF p_key2 IS NOT NULL THEN
        SELECT COALESCE(current_value, 0) INTO priority2
        FROM ontology.attribute
        WHERE entity_id = p_character_id AND domain = 'anthroposphere' AND key = 'worldview_' || p_key2;
    END IF;
    modifier_val := ((priority1 + priority2) / 10)::INT;
    roll_val := (random() * 20 + 1)::INT;
    total_val := roll_val + modifier_val;
    success_val := total_val >= p_difficulty;
    recommended_action := CASE WHEN success_val THEN 'follow_values' ELSE 'act_against_values' END;
    RETURN QUERY SELECT roll_val, modifier_val, total_val, success_val, recommended_action;
END;
$$ LANGUAGE plpgsql;

-- Внутренний конфликт
CREATE OR REPLACE FUNCTION ontology.apply_internal_conflict(
    p_character_id UUID,
    p_key1 TEXT,
    p_key2 TEXT DEFAULT NULL
)
RETURNS VOID AS $$
DECLARE
    need_attr TEXT;
    chakra_name TEXT;
BEGIN
    UPDATE ontology.attribute
    SET current_value = GREATEST(0, current_value - 10)
    WHERE entity_id = p_character_id AND domain = 'anthroposphere' AND key = 'willpower';
    IF p_key1 = 'duty' OR p_key2 = 'duty' THEN
        chakra_name := 'svadhisthana';
        need_attr := 'need_safety';
    ELSIF p_key1 = 'sacrifice' OR p_key2 = 'sacrifice' THEN
        chakra_name := 'anahata';
        need_attr := 'need_esteem';
    ELSE
        chakra_name := 'muladhara';
        need_attr := 'need_physiology';
    END IF;
    UPDATE ontology.attribute
    SET current_value = GREATEST(0, current_value - 15)
    WHERE entity_id = p_character_id AND domain = 'metaphysics' AND key = need_attr;
    UPDATE ontology.attribute
    SET current_value = GREATEST(0, current_value - 0.2)
    WHERE entity_id = p_character_id AND domain = 'metaphysics' AND key = 'chakra_' || chakra_name || '_openness';
    IF random() < 0.1 THEN
        INSERT INTO ontology.relation (subject_id, predicate, object_id)
        SELECT p_character_id, 'has_mutation', id
        FROM ontology.entity
        WHERE type = 'mutation' AND name = 'anxiety'
        ON CONFLICT DO NOTHING;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Очищение
CREATE OR REPLACE FUNCTION ontology.perform_cleansing(
    p_character_id UUID,
    p_cleansing_type TEXT
)
RETURNS TEXT AS $$
DECLARE
    will_recovery FLOAT;
    chakra_recovery FLOAT;
BEGIN
    CASE p_cleansing_type
        WHEN 'meditation' THEN
            will_recovery := 15;
            chakra_recovery := 0.2;
        WHEN 'sacrifice_ritual' THEN
            IF (SELECT SUM(amount * (metadata->>'value_in_base')::INT)
                FROM technosphere.coin_purse cp
                JOIN ontology.entity coin ON cp.coin_type_id = coin.id
                WHERE cp.character_id = p_character_id) < 50 THEN
                RETURN 'insufficient_funds';
            END IF;
            UPDATE technosphere.coin_purse
            SET amount = GREATEST(0, amount - 50 / (SELECT (metadata->>'value_in_base')::INT FROM ontology.entity WHERE id = coin_type_id))
            WHERE character_id = p_character_id;
            will_recovery := 25;
            chakra_recovery := 0.3;
        WHEN 'virtue_deed' THEN
            IF NOT EXISTS (
                SELECT 1 FROM ontology.relation r
                JOIN ontology.entity q ON r.object_id = q.id
                WHERE r.subject_id = p_character_id
                  AND r.predicate = 'completed_quest'
                  AND q.metadata->'tags' ? 'virtue_deed'
            ) THEN
                RETURN 'virtue_deed_not_completed';
            END IF;
            will_recovery := 30;
            chakra_recovery := 0.4;
        ELSE
            RETURN 'unknown_cleansing_type';
    END CASE;
    UPDATE ontology.attribute
    SET current_value = LEAST(100, current_value + will_recovery)
    WHERE entity_id = p_character_id AND domain = 'anthroposphere' AND key = 'willpower';
    UPDATE ontology.attribute
    SET current_value = LEAST(1.0, current_value + chakra_recovery)
    WHERE entity_id = p_character_id AND domain = 'metaphysics' AND key LIKE 'chakra_%_openness';
    RETURN 'success';
END;
$$ LANGUAGE plpgsql;

-- Применение целевой мутации
CREATE OR REPLACE FUNCTION ontology.apply_targeted_mutation(p_character_id UUID, p_element TEXT)
RETURNS VOID AS $$
DECLARE
    genome TEXT;
    new_genome TEXT;
    locus_index INT;
    locus TEXT;
    new_locus TEXT;
    pos INT;
    new_base CHAR(1);
    element_to_locus JSONB := '{
        "earth": 1, "water": 2, "fire": 3, "air": 4,
        "electricity": 5, "light": 6, "darkness": 7
    }';
BEGIN
    SELECT metadata->>'genome' INTO genome FROM ontology.entity WHERE id = p_character_id;
    locus_index := (element_to_locus->>p_element)::INT;
    locus := split_part(genome, '|', locus_index);
    pos := (random() * 4 + 1)::INT;
    IF locus_index <= 4 THEN
        new_base := CASE WHEN random() < 0.5 THEN 'G' ELSE 'C' END;
    ELSE
        new_base := CASE WHEN random() < 0.5 THEN 'A' ELSE 'T' END;
    END IF;
    new_locus := overlay(locus placing new_base from pos for 1);
    new_genome := '';
    FOR i IN 1..7 LOOP
        IF i > 1 THEN new_genome := new_genome || '|'; END IF;
        IF i = locus_index THEN
            new_genome := new_genome || new_locus;
        ELSE
            new_genome := new_genome || split_part(genome, '|', i);
        END IF;
    END LOOP;
    UPDATE ontology.entity
    SET metadata = jsonb_set(metadata, '{genome}', to_jsonb(new_genome))
    WHERE id = p_character_id;
    PERFORM ontology.initialize_traits_from_genome(p_character_id, new_genome);
    INSERT INTO ontology.relation (subject_id, predicate, object_id)
    SELECT p_character_id, 'has_mutation', id
    FROM ontology.entity
    WHERE type = 'mutation' AND name = 'spectrum_mutation';
END;
$$ LANGUAGE plpgsql;

-- Кризисная мутация
CREATE OR REPLACE FUNCTION ontology.apply_crisis_mutation(p_character_id UUID)
RETURNS VOID AS $$
DECLARE
    mutation_type TEXT;
    target TEXT;
    effect JSONB;
    rare_mutation_id UUID;
BEGIN
    mutation_type := (ARRAY['organ', 'body_zone', 'skill', 'psyche'])[floor(random() * 4 + 1)];
    CASE mutation_type
        WHEN 'organ' THEN
            target := (ARRAY['heart', 'lungs', 'brain', 'liver'])[floor(random() * 4 + 1)];
            effect := jsonb_build_object('organ_' || target, 
                CASE WHEN random() < 0.7 THEN '+20%' ELSE '-30%' END);
        WHEN 'body_zone' THEN
            target := (ARRAY['skin', 'eyes', 'hair', 'hands'])[floor(random() * 4 + 1)];
            effect := jsonb_build_object(target || '_mutation', 'active');
        WHEN 'skill' THEN
            target := (ARRAY['athletics', 'medicine', 'arcana', 'stealth'])[floor(random() * 4 + 1)];
            effect := jsonb_build_object('skill_' || target, 
                CASE WHEN random() < 0.6 THEN '+15' ELSE '-25' END);
        WHEN 'psyche' THEN
            target := (ARRAY['courage', 'empathy', 'logic', 'intuition'])[floor(random() * 4 + 1)];
            effect := jsonb_build_object('psyche_' || target, 
                CASE WHEN random() < 0.5 THEN 'enhanced' ELSE 'impaired' END);
    END CASE;
    IF random() < 0.05 THEN
        SELECT id INTO rare_mutation_id
        FROM ontology.entity
        WHERE type = 'mutation' 
          AND metadata->>'rarity' = 'mythical'
        ORDER BY random()
        LIMIT 1;
        IF rare_mutation_id IS NOT NULL THEN
            INSERT INTO ontology.relation (subject_id, predicate, object_id)
            VALUES (p_character_id, 'has_mutation', rare_mutation_id);
            RETURN;
        END IF;
    END IF;
    INSERT INTO ontology.relation (subject_id, predicate, object_id)
    SELECT p_character_id, 'has_mutation', id
    FROM ontology.entity
    WHERE type = 'mutation' AND name = 'crisis_mutation';
END;
$$ LANGUAGE plpgsql;

-- Проверка мутации
CREATE OR REPLACE FUNCTION ontology.check_for_mutation(p_character_id UUID)
RETURNS VOID AS $$
DECLARE
    trigger_effect RECORD;
    mutated BOOLEAN := false;
BEGIN
    FOR trigger_effect IN
        SELECT effect_type, magnitude
        FROM ontology.effect
        WHERE target_id = p_character_id
          AND active = true
          AND (ontology.get_effect_expires_at(created_at, duration_sec) IS NULL OR ontology.get_effect_expires_at(created_at, duration_sec) > NOW())
          AND effect_type LIKE 'mutation_trigger.%'
    LOOP
        DECLARE
            element TEXT := split_part(trigger_effect.effect_type, '.', 2);
            intensity FLOAT := trigger_effect.magnitude;
            mutation_chance FLOAT;
        BEGIN
            mutation_chance := GREATEST(0.05, (intensity - 0.7) * 0.3);
            IF random() < mutation_chance THEN
                PERFORM ontology.apply_targeted_mutation(p_character_id, element);
                mutated := true;
            END IF;
        END;
    END LOOP;
    IF mutated THEN
        PERFORM ontology.update_aura_rgb(p_character_id);
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Обновление кармы Хранителя
CREATE OR REPLACE FUNCTION ontology.update_keeper_karma(
    p_character_id UUID,
    p_keeper_id UUID,
    p_change FLOAT
)
RETURNS VOID AS $$
DECLARE
    current_val FLOAT;
BEGIN
    SELECT current_value INTO current_val
    FROM ontology.attribute
    WHERE entity_id = p_character_id
      AND domain = 'metaphysics'
      AND key = 'keeper_karma_' || p_keeper_id;
    IF current_val IS NULL THEN
        INSERT INTO ontology.attribute (entity_id, domain, key, base_value, current_value)
        VALUES (p_character_id, 'metaphysics', 'keeper_karma_' || p_keeper_id, 50, 50 + p_change);
    ELSE
        UPDATE ontology.attribute
        SET current_value = GREATEST(0, LEAST(100, current_val + p_change))
        WHERE entity_id = p_character_id
          AND domain = 'metaphysics'
          AND key = 'keeper_karma_' || p_keeper_id;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Ритуал призыва Хранителя
CREATE OR REPLACE FUNCTION ontology.perform_keeper_ritual(
    p_character_id UUID,
    p_ritual_id UUID
)
RETURNS TEXT AS $$
DECLARE
    ritual_data JSONB;
    keeper_name TEXT;
    keeper_id UUID;
    required_karma INT;
    current_karma FLOAT;
    has_item BOOLEAN := false;
    in_location BOOLEAN := false;
BEGIN
    SELECT metadata INTO ritual_data FROM ontology.entity WHERE id = p_ritual_id;
    keeper_name := ritual_data->>'keeper';
    required_karma := (ritual_data->>'required_karma')::INT;
    SELECT id INTO keeper_id FROM ontology.entity WHERE name = keeper_name;
    SELECT current_value INTO current_karma
    FROM ontology.attribute
    WHERE entity_id = p_character_id
      AND domain = 'metaphysics'
      AND key = 'keeper_karma_' || keeper_id;
    IF COALESCE(current_karma, 0) < required_karma THEN
        RETURN 'insufficient_karma';
    END IF;
    IF ritual_data ? 'required_item' THEN
        SELECT EXISTS (
            SELECT 1 FROM ontology.relation r
            JOIN ontology.entity item ON r.object_id = item.id
            WHERE r.subject_id = p_character_id
              AND r.predicate = 'possesses'
              AND item.name = ritual_data->>'required_item'
        ) INTO has_item;
        IF NOT has_item THEN
            RETURN 'missing_ritual_item';
        END IF;
    END IF;
    IF ritual_data ? 'required_location' THEN
        SELECT EXISTS (
            SELECT 1 FROM ontology.relation r
            JOIN ontology.entity loc ON r.object_id = loc.id
            WHERE r.subject_id = p_character_id
              AND r.predicate = 'located_in'
              AND loc.metadata->>'type' = ritual_data->>'required_location'
        ) INTO in_location;
        IF NOT in_location THEN
            RETURN 'wrong_location';
        END IF;
    END IF;
    INSERT INTO ontology.effect (
        source_id, target_id, domain, effect_type, magnitude, duration_sec, operation
    ) VALUES (
        keeper_id,
        p_character_id,
        'metaphysics',
        'keeper_presence.' || keeper_name,
        1.0,
        (ritual_data->>'duration_sec')::INT,
        'set'
    );
    INSERT INTO ontology.notification (
        character_id, title, message, source_id
    ) VALUES (
        p_character_id,
        'Ритуал завершён',
        keeper_name || ' откликнулся на ваш зов.',
        keeper_id
    );
    RETURN 'success';
END;
$$ LANGUAGE plpgsql;

-- Генерация динамического квеста
CREATE OR REPLACE FUNCTION ontology.generate_dynamic_quest(
    p_character_id UUID,
    p_region_id UUID
)
RETURNS UUID AS $$
DECLARE
    quest_id UUID;
    region_spectrum JSONB;
    dominant_color TEXT;
    max_intensity FLOAT := 0;
    color TEXT;
    intensity FLOAT;
BEGIN
    SELECT metadata->'spectrum' INTO region_spectrum FROM ontology.entity WHERE id = p_region_id;
    FOR color IN SELECT jsonb_object_keys(region_spectrum) LOOP
        intensity := (region_spectrum->>color)::FLOAT;
        IF intensity > max_intensity THEN
            max_intensity := intensity;
            dominant_color := color;
        END IF;
    END LOOP;
    CASE dominant_color
        WHEN 'earth' THEN
            INSERT INTO ontology.entity (type, name, metadata)
            VALUES ('quest', 'Найти источник воды',
                '{"description": "В пустыне жажда убивает. Найди оазис.", "keys": ["survival"]}')
            RETURNING id INTO quest_id;
        WHEN 'air' THEN
            INSERT INTO ontology.entity (type, name, metadata)
            VALUES ('quest', 'Доставить лекарство старейшине',
                '{"description": "Старейшина болен. Спаси его!", "keys": ["duty", "sacrifice"], "tags": ["virtue_deed"]}')
            RETURNING id INTO quest_id;
        ELSE
            INSERT INTO ontology.entity (type, name, metadata)
            VALUES ('quest', 'Исследовать окрестности',
                '{"description": "Что скрывает эта земля?", "keys": ["curiosity"]}')
            RETURNING id INTO quest_id;
    END CASE;
    INSERT INTO ontology.relation (subject_id, predicate, object_id)
    VALUES (p_character_id, 'assigned_quest', quest_id);
    RETURN quest_id;
END;
$$ LANGUAGE plpgsql;

-- Обновление погоды
CREATE OR REPLACE FUNCTION ontology.update_weather(p_region_id UUID)
RETURNS VOID AS $$
DECLARE
    spectrum JSONB; dominant_color TEXT; max_intensity FLOAT := 0; color TEXT; intensity FLOAT; new_weather TEXT;
BEGIN
    SELECT metadata->'spectrum' INTO spectrum FROM ontology.entity WHERE id = p_region_id;
    IF spectrum IS NULL THEN RETURN; END IF;
    FOR color IN SELECT jsonb_object_keys(spectrum) LOOP
        intensity := (spectrum->>color)::FLOAT;
        IF intensity > max_intensity THEN
            max_intensity := intensity;
            dominant_color := color;
        END IF;
    END LOOP;
    CASE dominant_color
        WHEN 'earth' THEN new_weather := 'dust_storm';
        WHEN 'fire' THEN new_weather := 'heat_wave';
        WHEN 'air' THEN new_weather := 'gentle_breeze';
        WHEN 'darkness' THEN new_weather := 'reality_rift';
        ELSE new_weather := 'clear';
    END CASE;
    UPDATE ontology.entity
    SET metadata = jsonb_set(COALESCE(metadata, '{}'), '{current_weather}', to_jsonb(new_weather))
    WHERE id = p_region_id;
END;
$$ LANGUAGE plpgsql;

-- Обновление эгрегора
CREATE OR REPLACE FUNCTION ontology.update_egregor(p_egregor_id UUID)
RETURNS VOID AS $$
DECLARE
    total_power FLOAT := 0;
    follower RECORD;
BEGIN
    FOR follower IN
        SELECT r.subject_id
        FROM ontology.relation r
        WHERE r.object_id = p_egregor_id AND r.predicate = 'connected_to_egregor'
    LOOP
        total_power := total_power + 1;
    END LOOP;
    UPDATE ontology.entity
    SET metadata = jsonb_set(metadata, '{power}', to_jsonb(total_power))
    WHERE id = p_egregor_id;
END;
$$ LANGUAGE plpgsql;

-- Старение персонажей
CREATE OR REPLACE FUNCTION ontology.age_all_characters()
RETURNS VOID AS $$
BEGIN
    UPDATE ontology.entity
    SET age = age + 1
    WHERE type = 'character' AND status = 'alive';
END;
$$ LANGUAGE plpgsql;

-- Проверка социальных связей
CREATE OR REPLACE FUNCTION ontology.check_social_bonds()
RETURNS VOID AS $$
DECLARE
    pair RECORD;
BEGIN
    FOR pair IN
        SELECT r1.subject_id AS c1, r2.subject_id AS c2
        FROM ontology.relation r1
        JOIN ontology.relation r2 ON r1.object_id = r2.object_id
        WHERE r1.predicate = 'located_in'
          AND r2.predicate = 'located_in'
          AND r1.subject_id < r2.subject_id
          AND NOT EXISTS (
              SELECT 1 FROM ontology.relation
              WHERE subject_id = r1.subject_id AND object_id = r2.subject_id AND predicate = 'knows'
          )
    LOOP
        IF random() < 0.05 THEN
            INSERT INTO ontology.relation (subject_id, predicate, object_id)
            VALUES (pair.c1, 'knows', pair.c2), (pair.c2, 'knows', pair.c1);
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- World tick: саморазвитие мира
CREATE OR REPLACE FUNCTION ontology.world_tick()
RETURNS VOID AS $$
DECLARE
    region RECORD;
    pair RECORD;
    child_id UUID;
    npc RECORD;
BEGIN
    -- Старение
    PERFORM ontology.age_all_characters();

    -- Рождение новых НПС
    FOR pair IN
        SELECT r1.subject_id AS parent1, r2.subject_id AS parent2, r1.object_id AS region
        FROM ontology.relation r1
        JOIN ontology.relation r2 ON r1.object_id = r2.object_id
        WHERE r1.predicate = 'located_in'
          AND r2.predicate = 'located_in'
          AND r1.subject_id != r2.subject_id
          AND EXISTS (SELECT 1 FROM ontology.entity WHERE id = r1.subject_id AND age BETWEEN 18 AND 50 AND status = 'alive')
          AND EXISTS (SELECT 1 FROM ontology.entity WHERE id = r2.subject_id AND age BETWEEN 18 AND 50 AND status = 'alive')
    LOOP
        IF random() < 0.01 THEN
            child_id := ontology.create_child(pair.parent1, pair.parent2, 'Ребёнок');
            INSERT INTO ontology.relation (subject_id, predicate, object_id)
            VALUES (child_id, 'located_in', pair.region);
        END IF;
    END LOOP;

    -- Смерть
    FOR npc IN
        SELECT id, age
        FROM ontology.entity
        WHERE type = 'character'
          AND status = 'alive'
          AND (
              age > 80 OR
              (SELECT current_value FROM ontology.attribute WHERE entity_id = id AND domain = 'biology' AND key = 'body_strength') < 10
          )
    LOOP
        UPDATE ontology.entity SET status = 'dead' WHERE id = npc.id;
    END LOOP;

    -- Взаимодействие с маятниками и мутациями
    FOR npc IN
        SELECT id FROM ontology.entity WHERE type = 'character' AND status = 'alive'
    LOOP
        PERFORM ontology.check_for_mutation(npc.id);
        PERFORM ontology.check_social_bonds();
    END LOOP;

    -- Обновление регионов
    FOR region IN SELECT id FROM ontology.entity WHERE type = 'region' LOOP
        PERFORM ontology.update_weather(region.id);
    END LOOP;

    -- Обновление эгрегоров
    FOR region IN SELECT id FROM ontology.entity WHERE type = 'egregor' LOOP
        PERFORM ontology.update_egregor(region.id);
    END LOOP;

    -- Обновление времени мира (+1 день)
    UPDATE ontology.entity
    SET metadata = jsonb_set(metadata, '{current_time_sec}', to_jsonb((metadata->>'current_time_sec')::INT + 86400))
    WHERE type = 'world';
END;
$$ LANGUAGE plpgsql;

-- === 9. ТРИГГЕРЫ ===

CREATE OR REPLACE FUNCTION ontology.on_effect_change()
RETURNS TRIGGER AS $$
DECLARE
    parsed RECORD;
BEGIN
    SELECT * INTO parsed FROM ontology.parse_effect_type(
        CASE WHEN TG_OP = 'DELETE' THEN OLD.effect_type ELSE NEW.effect_type END
    );
    IF parsed.domain IS NOT NULL AND parsed.key IS NOT NULL THEN
        PERFORM ontology.recalculate_attribute(
            CASE WHEN TG_OP = 'DELETE' THEN OLD.target_id ELSE NEW.target_id END,
            parsed.domain,
            parsed.key
        );
    END IF;
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_effect_recalc
AFTER INSERT OR UPDATE OR DELETE ON ontology.effect
FOR EACH ROW EXECUTE FUNCTION ontology.on_effect_change();

-- === 10. Индексы ===
CREATE INDEX idx_entity_type ON ontology.entity(type);
CREATE INDEX idx_relation_subject ON ontology.relation(subject_id);
CREATE INDEX idx_relation_object ON ontology.relation(object_id);
CREATE INDEX idx_effect_target ON ontology.effect(target_id);
CREATE INDEX idx_attribute_entity ON ontology.attribute(entity_id);

-- === ГОТОВО! ===