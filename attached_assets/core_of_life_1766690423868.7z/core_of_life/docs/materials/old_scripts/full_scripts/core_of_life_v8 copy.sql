
-- === 3. AUTH ===
-- 3.1
CREATE TABLE auth.account (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- === 19. ТРИГГЕРЫ ===
-- 19.1
CREATE OR REPLACE FUNCTION ontology.on_effect_change()
RETURNS TRIGGER AS $$
DECLARE
    parsed RECORD;
BEGIN
    SELECT * INTO parsed FROM ontology.parse_effect_type(
        CASE WHEN TG_OP = 'DELETE' THEN OLD.effect_type ELSE NEW.effect_type END
    );
    IF parsed.domain IS NOT NULL AND parsed.key IS NOT NULL THEN
        PERFORM ontology.recalculate_attribute(
            CASE WHEN TG_OP = 'DELETE' THEN OLD.target_id ELSE NEW.target_id END,
            parsed.domain,
            parsed.key
        );
    END IF;
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- 19.2
CREATE TRIGGER trg_effect_recalc
AFTER INSERT OR UPDATE OR DELETE ON ontology.effect
FOR EACH ROW EXECUTE FUNCTION ontology.on_effect_change();

-- === 20. VIEW ===
-- 20.1 v_character_chakras (исправленный)
CREATE OR REPLACE VIEW ontology.v_character_chakras AS
SELECT
    e.id AS character_id,
    e.name AS character_name,
    ch.chakra_name,
    ch.need_name,
    ch.spectrum_color,
    COALESCE(a.current_value, 0.01) AS openness_percent,
    CASE
        WHEN COALESCE(a.current_value, 0.01) >= 70.0 THEN 'radiating'
        WHEN COALESCE(a.current_value, 0.01) >= 30.0 THEN 'absorbing'
        ELSE 'closed'
    END AS state
FROM ontology.entity e
CROSS JOIN (
    VALUES
        ('muladhara', 'Физиология', 'earth'),
        ('svadhisthana', 'Безопасность', 'water'),
        ('manipura', 'Принадлежность', 'fire'),
        ('anahata', 'Признание', 'air'),
        ('vishuddha', 'Познание', 'electricity'),
        ('ajna', 'Эстетика', 'light'),
        ('sahasrara', 'Самоактуализация', 'darkness')
) AS ch(chakra_name, need_name, spectrum_color)
LEFT JOIN ontology.attribute a 
  ON a.entity_id = e.id 
 AND a.domain = 'metaphysics'
 AND a.key = 'chakra_' || ch.chakra_name || '_openness'
WHERE e.type = 'character';

-- 20.2 v_observer_view
CREATE OR REPLACE VIEW ontology.v_observer_view AS
SELECT
    e.id AS character_id,
    e.name,
    e.metadata->'aura_rgb' AS aura_rgb,
    e.timeline,
    (SELECT jsonb_agg(jsonb_build_object(
        'chakra', ch.chakra_name,
        'openness', ch.openness_percent,
        'state', ch.state,
        'color', ch.spectrum_color
    )) FROM ontology.v_character_chakras ch WHERE ch.character_id = e.id) AS chakras,
    (SELECT jsonb_agg(jsonb_build_object(
        'id', c.id,
        'content', c.content,
        'influence', c.influence
    )) FROM ontology.comment c WHERE c.target_id = e.id) AS noosphere_voices
FROM ontology.entity e
WHERE e.type = 'character';

-- 20.3 v_svg_character
CREATE OR REPLACE VIEW ontology.v_svg_character AS
SELECT
    e.id AS character_id,
    e.name,
    e.metadata->'aura_rgb' AS aura_rgb,
    (SELECT jsonb_agg(jsonb_build_object(
        'index', idx,
        'color', spectrum_color,
        'openness', openness_percent,
        'state', state,
        'x', 200 + 50 * COS(2 * PI() * (idx-1) / 7),
        'y', 200 + 50 * SIN(2 * PI() * (idx-1) / 7),
        'radius', 15 + (openness_percent / 100) * 20
    )) FROM (
        SELECT 
            ROW_NUMBER() OVER () AS idx,
            chakra_name,
            spectrum_color,
            openness_percent,
            state
        FROM ontology.v_character_chakras
        WHERE character_id = e.id
        ORDER BY 
            CASE chakra_name
                WHEN 'muladhara' THEN 1
                WHEN 'svadhisthana' THEN 2
                WHEN 'manipura' THEN 3
                WHEN 'anahata' THEN 4
                WHEN 'vishuddha' THEN 5
                WHEN 'ajna' THEN 6
                WHEN 'sahasrara' THEN 7
            END
    ) AS ordered_chakras) AS chakras_svg
FROM ontology.entity e
WHERE e.type = 'character';

