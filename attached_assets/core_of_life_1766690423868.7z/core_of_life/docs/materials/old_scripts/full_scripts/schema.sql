-- === Общее ===
CREATE EXTENSION IF NOT EXISTS "uuid-ossp"; -- Расширение PostgreSQL для генерации UUID

-- === 1. AuthService (Сервис аутентификации) ===
-- Таблица аккаунтов пользователей
CREATE TABLE account (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), -- Уникальный идентификатор аккаунта
    email VARCHAR(255) UNIQUE NOT NULL,            -- Электронная почта (уникальная)
    password_hash TEXT NOT NULL,                   -- Хеш пароля
    created_at TIMESTAMP DEFAULT NOW()             -- Дата и время создания аккаунта
);

-- === 2. GeoService (Геосервис) ===
-- Таблица материалов (для монет и предметов)
CREATE TABLE material (
    id SERIAL PRIMARY KEY,                         -- Уникальный идентификатор материала
    name VARCHAR(50) NOT NULL UNIQUE,              -- Название материала ('золото', 'серебро', 'медь')
    density DOUBLE PRECISION,                      -- Плотность материала (г/см³)
    color_rgb JSONB                                -- Цвет материала в формате RGB [R, G, B]
);

-- Таблица типов геообъектов
CREATE TABLE geo_object_type (
    id SERIAL PRIMARY KEY,                         -- Уникальный идентификатор типа
    name VARCHAR(50) NOT NULL UNIQUE               -- Название типа ('village', 'forest', 'ruins')
);

-- Таблица регионов (областей мира)
CREATE TABLE region (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), -- Уникальный идентификатор региона
    name VARCHAR(100) NOT NULL,                    -- Название региона
    parent_region_id UUID REFERENCES region(id)    -- Ссылка на родительский регион (для иерархии)
);

-- Таблица вершин региона (для 3D-границ)
CREATE TABLE region_vertex (
    id SERIAL PRIMARY KEY,                         -- Уникальный идентификатор вершины
    region_id UUID NOT NULL REFERENCES region(id) ON DELETE CASCADE, -- Ссылка на регион
    latitude DOUBLE PRECISION NOT NULL,            -- Широта (координата X)
    longitude DOUBLE PRECISION NOT NULL,           -- Долгота (координата Y)
    elevation DOUBLE PRECISION NOT NULL DEFAULT 0.0, -- Высота над уровнем моря (координата Z)
    vertex_order INT NOT NULL,                     -- Порядок вершины при обходе полигона
    UNIQUE(region_id, vertex_order)                -- Уникальность: (регион, порядок)
);

-- Таблица геообъектов (конкретные места: деревни, руины и т.д.)
CREATE TABLE geo_object (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), -- Уникальный идентификатор геообъекта
    name VARCHAR(100) NOT NULL,                    -- Название объекта
    type_id INT NOT NULL REFERENCES geo_object_type(id), -- Ссылка на тип объекта
    latitude DOUBLE PRECISION NOT NULL,            -- Широта
    longitude DOUBLE PRECISION NOT NULL,           -- Долгота
    elevation DOUBLE PRECISION NOT NULL DEFAULT 0.0, -- Высота
    region_id UUID REFERENCES region(id)           -- Ссылка на регион
);

-- Таблица альтернативных названий геообъектов (от игроков)
CREATE TABLE geo_object_alias (
    id SERIAL PRIMARY KEY,                         -- Уникальный идентификатор алиаса
    geo_object_id UUID NOT NULL REFERENCES geo_object(id), -- Ссылка на геообъект
    alias_name VARCHAR(100) NOT NULL,              -- Альтернативное название ("Дом у Корней")
    created_by_character_id UUID,                  -- Кто создал название (ссылка на персонажа)
    created_at TIMESTAMP DEFAULT NOW(),            -- Дата создания
    is_approved BOOLEAN DEFAULT false              -- Одобрено ли название модератором
);

-- === 3. LivingObjectService (Сервис живых объектов) ===
-- Таблица персонажей
CREATE TABLE character (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), -- Уникальный идентификатор персонажа
    name VARCHAR(100) NOT NULL,                    -- Имя персонажа
    title VARCHAR(100),                            -- Звание (задаётся игроком, например "Голос корней")
    father_id UUID REFERENCES character(id),       -- Ссылка на отца (персонаж)
    mother_id UUID REFERENCES character(id),       -- Ссылка на мать (персонаж)
    gender VARCHAR(20),                            -- Пол персонажа
    birth_date DATE,                               -- Дата рождения
    birth_place_id UUID NOT NULL REFERENCES geo_object(id), -- Место рождения (геообъект)
    account_id UUID NOT NULL REFERENCES account(id) -- Владелец персонажа (аккаунт)
);

-- Таблица происхождения (генетика)
CREATE TABLE origin (
    character_id UUID PRIMARY KEY REFERENCES character(id), -- Ссылка на персонажа
    genome TEXT NOT NULL DEFAULT 'AAAA|TTTT|CCCC|GGGG|ATAT|CGCG|ACGT', -- Геном в формате "ATAT|TCTC|..."
    growth_type VARCHAR(20) CHECK (growth_type IN ('balanced','slow','fast','chosen')) -- Тип роста
);

-- Таблица базовых характеристик
CREATE TABLE ability_score (
    character_id UUID PRIMARY KEY REFERENCES character(id), -- Ссылка на персонажа
    strength INT NOT NULL DEFAULT 10,              -- Сила
    dexterity INT NOT NULL DEFAULT 10,             -- Ловкость
    constitution INT NOT NULL DEFAULT 10,          -- Телосложение
    intelligence INT NOT NULL DEFAULT 10,          -- Интеллект
    wisdom INT NOT NULL DEFAULT 10,                -- Мудрость
    charisma INT NOT NULL DEFAULT 10               -- Харизма
);

-- Таблица навыков (справочник)
CREATE TABLE skill (
    id SERIAL PRIMARY KEY,                         -- Уникальный идентификатор навыка
    name VARCHAR(50) NOT NULL UNIQUE               -- Название навыка ('athletics', 'medicine')
);

-- Таблица владения навыками персонажами
CREATE TABLE character_skill (
    character_id UUID NOT NULL REFERENCES character(id), -- Ссылка на персонажа
    skill_id INT NOT NULL REFERENCES skill(id),    -- Ссылка на навык
    has_proficiency BOOLEAN NOT NULL DEFAULT false, -- Владеет ли персонаж навыком
    modifier INT NOT NULL DEFAULT 0,               -- Модификатор навыка
    PRIMARY KEY (character_id, skill_id)           -- Составной первичный ключ
);

-- Таблица физиологии персонажа
CREATE TABLE physiology (
    character_id UUID PRIMARY KEY REFERENCES character(id), -- Ссылка на персонажа
    body_strength INT NOT NULL DEFAULT 0 CHECK (body_strength BETWEEN 0 AND 100), -- Сила тела (0–100%)
    organ_health JSONB,                            -- Здоровье органов в формате {"heart": 95, "lungs": 88}
    stamina INT NOT NULL DEFAULT 100               -- Выносливость (0–100)
);

-- Таблица предыстории персонажа
CREATE TABLE backstory (
    character_id UUID PRIMARY KEY REFERENCES character(id), -- Ссылка на персонажа
    personality_traits TEXT,                       -- Черты характера
    worldview TEXT,                                -- Мировоззрение
    ideals TEXT,                                   -- Идеалы
    bonds TEXT,                                    -- Привязанности
    flaws TEXT,                                    -- Слабости
    allies TEXT,                                   -- Союзники
    enemies TEXT                                   -- Враги
);

-- Таблица боевых параметров
CREATE TABLE combat_stats (
    character_id UUID PRIMARY KEY REFERENCES character(id), -- Ссылка на персонажа
    current_hp INT NOT NULL DEFAULT 10,            -- Текущие пункты здоровья
    max_hp INT NOT NULL DEFAULT 10,                -- Максимальные пункты здоровья
    temp_hp INT NOT NULL DEFAULT 0,                -- Временные пункты здоровья
    armor_class INT NOT NULL DEFAULT 10,           -- Класс доспеха
    initiative INT NOT NULL DEFAULT 0,             -- Инициатива
    speed INT NOT NULL DEFAULT 30,                 -- Скорость
    proficiency_bonus INT NOT NULL DEFAULT 2,      -- Бонус мастерства
    inspiration INT NOT NULL DEFAULT 0,            -- Вдохновение
    spell_save_dc INT NOT NULL DEFAULT 10,         -- Сложность спасброска от заклинаний
    spell_attack_bonus INT NOT NULL DEFAULT 0,     -- Бонус к атаке заклинаниями
    experience_points INT NOT NULL DEFAULT 0,      -- Пункты опыта
    completed_sessions INT NOT NULL DEFAULT 0      -- Количество завершённых игровых сессий
);

-- Таблица костей хитов
CREATE TABLE hit_dice (
    character_id UUID PRIMARY KEY REFERENCES character(id), -- Ссылка на персонажа
    dice_type VARCHAR(10) NOT NULL,                -- Тип кости ('1d8')
    total_count INT NOT NULL,                      -- Общее количество костей
    used_count INT NOT NULL DEFAULT 0              -- Количество использованных костей
);

-- Таблица спасбросков от смерти
CREATE TABLE death_saves (
    character_id UUID PRIMARY KEY REFERENCES character(id), -- Ссылка на персонажа
    successes INT NOT NULL DEFAULT 0,              -- Количество успехов
    failures INT NOT NULL DEFAULT 0                -- Количество провалов
);

-- Таблица ячеек заклинаний
CREATE TABLE spell_slot (
    character_id UUID NOT NULL REFERENCES character(id), -- Ссылка на персонажа
    spell_level INT NOT NULL CHECK (spell_level BETWEEN 1 AND 9), -- Уровень заклинания (1–9)
    total_slots INT NOT NULL,                      -- Общее количество ячеек
    used_slots INT NOT NULL DEFAULT 0,             -- Количество использованных ячеек
    PRIMARY KEY (character_id, spell_level)        -- Составной первичный ключ
);

-- Таблица тумана войны (открытые области)
CREATE TABLE fog_of_war (
    character_id UUID NOT NULL,                    -- Ссылка на персонажа
    geo_object_id UUID,                            -- Ссылка на геообъект (если открыт)
    region_id UUID,                                -- Ссылка на регион (если открыт)
    discovered_at TIMESTAMP DEFAULT NOW(),         -- Дата открытия
    is_explored BOOLEAN DEFAULT false,             -- Полностью ли исследован объект/регион
    PRIMARY KEY (character_id, geo_object_id, region_id) -- Составной первичный ключ
);

-- === 4. GeneticsService (Сервис генетики) ===
-- Таблица физиологических мутаций (справочник)
CREATE TABLE physiological_mutation (
    id SERIAL PRIMARY KEY,                         -- Уникальный идентификатор мутации
    name VARCHAR(50) NOT NULL UNIQUE,              -- Системное имя мутации
    display_name VARCHAR(100) NOT NULL,            -- Отображаемое имя мутации
    effect_json JSONB NOT NULL                     -- Эффекты мутации в формате JSON
);

-- Таблица мутаций персонажей
CREATE TABLE character_mutation (
    character_id UUID NOT NULL,                    -- Ссылка на персонажа
    mutation_id INT NOT NULL REFERENCES physiological_mutation(id), -- Ссылка на мутацию
    PRIMARY KEY (character_id, mutation_id)        -- Составной первичный ключ
);

-- Таблица предрасположенности к стихиям (скрытая механика)
CREATE TABLE elemental_affinity (
    character_id UUID NOT NULL,                    -- Ссылка на персонажа
    element_type VARCHAR(20) NOT NULL CHECK (element_type IN ('cold', 'fire', 'lightning', 'earth', 'air', 'water')), -- Тип стихии
    affinity_level INT NOT NULL DEFAULT 0 CHECK (affinity_level BETWEEN 0 AND 100), -- Уровень предрасположенности (0–100)
    PRIMARY KEY (character_id, element_type)       -- Составной первичный ключ
);

-- === 5. MetaphysicalService (Метафизический сервис) ===
-- Таблица метафизического профиля (Ци и Энергия Чакр)
CREATE TABLE metaphysical_profile (
    character_id UUID PRIMARY KEY,                 -- Ссылка на персонажа
    qi_capacity INT NOT NULL DEFAULT 50 CHECK (qi_capacity BETWEEN 0 AND 100), -- Ёмкость Ци (0–100)
    qi_flow INT NOT NULL DEFAULT 5,                -- Поток Ци
    qi_purity FLOAT NOT NULL DEFAULT 0.7,          -- Чистота Ци (0.0–1.0)
    chakra_energy_capacity INT NOT NULL DEFAULT 50, -- Ёмкость энергии чакр
    chakra_energy_flow INT NOT NULL DEFAULT 5,     -- Поток энергии чакр
    aura_radius DOUBLE PRECISION NOT NULL DEFAULT 1.0, -- Радиус ауры (в метрах)
    karma_balance INT NOT NULL DEFAULT 0           -- Баланс кармы
);

-- Таблица чакр (справочник)
CREATE TABLE chakra (
    id SERIAL PRIMARY KEY,                         -- Уникальный идентификатор чакры
    name VARCHAR(30) NOT NULL UNIQUE,              -- Системное имя ('muladhara', 'anahata')
    display_name VARCHAR(50) NOT NULL,             -- Отображаемое имя ('Муладхара', 'Анахата')
    color VARCHAR(20) NOT NULL,                    -- Цвет чакры ('red', 'green')
    position INT NOT NULL UNIQUE CHECK (position BETWEEN 1 AND 7), -- Позиция (1–7)
    required_lower_chakra_id INT REFERENCES chakra(id), -- Требуемая нижняя чакра для открытия
    required_openness_threshold FLOAT DEFAULT 0.5  -- Порог открытости нижней чакры (0.0–1.0)
);

-- Таблица состояния чакр у персонажей
CREATE TABLE character_chakra (
    character_id UUID NOT NULL,                    -- Ссылка на персонажа
    chakra_id INT NOT NULL REFERENCES chakra(id),  -- Ссылка на чакру
    sequence VARCHAR(12) NOT NULL,                 -- Генетический код чакры
    openness FLOAT NOT NULL DEFAULT 0.0 CHECK (openness BETWEEN 0 AND 1), -- Открытость чакры (0.0–1.0)
    energy_level INT NOT NULL DEFAULT 0 CHECK (energy_level BETWEEN 0 AND 100), -- Уровень энергии (0–100%)
    has_ever_been_opened BOOLEAN NOT NULL DEFAULT false, -- Была ли чакра открыта ранее
    PRIMARY KEY (character_id, chakra_id)          -- Составной первичный ключ
);

-- === 6. ItemService (Сервис предметов) ===
-- Таблица типов предметов
CREATE TABLE item_type (
    id SERIAL PRIMARY KEY,                         -- Уникальный идентификатор типа
    name VARCHAR(30) NOT NULL UNIQUE               -- Название типа ('weapon', 'armor', 'shield')
);

-- Таблица редкости предметов
CREATE TABLE rarity (
    id SERIAL PRIMARY KEY,                         -- Уникальный идентификатор редкости
    name VARCHAR(20) NOT NULL UNIQUE,              -- Название редкости ('обычный', 'редкий', ...)
    sort_order INT NOT NULL                        -- Порядок сортировки
);

-- Таблица предметов
CREATE TABLE item (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), -- Уникальный идентификатор предмета
    name VARCHAR(100) NOT NULL,                    -- Название предмета
    item_type_id INT NOT NULL REFERENCES item_type(id), -- Ссылка на тип предмета
    rarity_id INT NOT NULL REFERENCES rarity(id),  -- Ссылка на редкость
    material_id INT REFERENCES material(id),       -- Ссылка на материал
    weight_kg FLOAT,                               -- Вес в килограммах
    size_description TEXT,                         -- Описание размера
    condition TEXT,                                -- Состояние предмета
    price_gold INT                                 -- Цена в золотых монетах
);

-- Таблица оружия (расширение предметов)
CREATE TABLE weapon (
    item_id UUID PRIMARY KEY REFERENCES item(id),  -- Ссылка на предмет
    damage_dice VARCHAR(20) NOT NULL,              -- Урон в формате '1d6'
    damage_type VARCHAR(20) NOT NULL,              -- Тип урона ('колющий', 'режущий', 'дробящий')
    range_m INT                                    -- Дальность действия в метрах
);

-- Таблица доспехов и щитов (расширение предметов)
CREATE TABLE armor (
    item_id UUID PRIMARY KEY REFERENCES item(id),  -- Ссылка на предмет
    armor_category VARCHAR(20) NOT NULL,           -- Категория защиты ('легкий', 'средний', 'тяжелый')
    armor_class_bonus INT NOT NULL                 -- Бонус к классу доспеха
);

-- Таблица типов монет
CREATE TABLE coin_type (
    id SERIAL PRIMARY KEY,                         -- Уникальный идентификатор типа монеты
    code VARCHAR(2) NOT NULL UNIQUE,               -- Код монеты ('ММ', 'СМ', 'ЗМ', 'ЭМ', 'ПМ')
    name VARCHAR(50) NOT NULL,                     -- Название монеты
    material_id INT NOT NULL REFERENCES material(id), -- Ссылка на материал
    nominal_value_in_copper INT NOT NULL           -- Номинал в медных монетах
);

-- Таблица кошельков персонажей
CREATE TABLE coin_purse (
    character_id UUID NOT NULL,                    -- Ссылка на персонажа
    coin_type_id INT NOT NULL REFERENCES coin_type(id), -- Ссылка на тип монеты
    amount INT NOT NULL DEFAULT 0 CHECK (amount >= 0), -- Количество монет
    PRIMARY KEY (character_id, coin_type_id)       -- Составной первичный ключ
);

-- Таблица предметов в инвентаре
CREATE TABLE inventory_item (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), -- Уникальный идентификатор записи
    character_id UUID NOT NULL,                    -- Ссылка на персонажа
    item_id UUID NOT NULL REFERENCES item(id),     -- Ссылка на предмет
    quantity INT NOT NULL DEFAULT 1                -- Количество предметов
);

-- === 7. WeatherService (Сервис погоды) ===
-- Таблица типов климата
CREATE TABLE climate_type (
    id SERIAL PRIMARY KEY,                         -- Уникальный идентификатор типа климата
    name VARCHAR(50) NOT NULL UNIQUE,              -- Название климата
    temperature_base INT NOT NULL,                 -- Базовая температура (°C)
    humidity_level INT NOT NULL CHECK (humidity_level BETWEEN 0 AND 100) -- Уровень влажности (0–100%)
);

-- Таблица климата регионов
CREATE TABLE region_climate (
    region_id UUID PRIMARY KEY,                    -- Ссылка на регион
    climate_type_id INT NOT NULL REFERENCES climate_type(id) -- Ссылка на тип климата
);

-- Таблица текущей погоды
CREATE TABLE current_weather (
    region_id UUID PRIMARY KEY,                    -- Ссылка на регион
    time_of_day VARCHAR(20) NOT NULL,              -- Время суток ('morning', 'day', 'evening', 'night')
    season VARCHAR(20) NOT NULL,                   -- Сезон ('spring', 'summer', 'autumn', 'winter')
    weather_type VARCHAR(50),                      -- Тип погоды ('clear', 'rain', 'storm')
    magical_intensity FLOAT DEFAULT 0.0,           -- Интенсивность магической активности (0.0–1.0)
    updated_at TIMESTAMP DEFAULT NOW()             -- Дата и время последнего обновления
);