-- === Общее ===
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- === 1. AuthService (auth_db) ===
CREATE TABLE account (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);