-- === Общее ===
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- === 4. GeneticsService (genetics_db) ===
CREATE TABLE physiological_mutation (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    display_name VARCHAR(100) NOT NULL,
    effect_json JSONB NOT NULL,
    element_type VARCHAR(20)  -- 'cold', 'fire', ...
);

CREATE TABLE character_mutation (
    character_id UUID NOT NULL,
    mutation_id INT NOT NULL REFERENCES physiological_mutation(id),
    PRIMARY KEY (character_id, mutation_id)
);