-- === Общее ===
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- === 2. GeoService (geo_db) ===
CREATE TABLE geo_object_type (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE           -- 'village', 'forest', 'ruins'
);

CREATE TABLE region (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    parent_region_id UUID REFERENCES region(id)
);

CREATE TABLE region_vertex (
    id SERIAL PRIMARY KEY,
    region_id UUID NOT NULL REFERENCES region(id) ON DELETE CASCADE,
    latitude DOUBLE PRECISION NOT NULL,        -- широта
    longitude DOUBLE PRECISION NOT NULL,       -- долгота
    elevation DOUBLE PRECISION NOT NULL DEFAULT 0.0,  -- высота
    vertex_order INT NOT NULL,
    UNIQUE(region_id, vertex_order)
);

CREATE TABLE geo_object (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    type_id INT NOT NULL REFERENCES geo_object_type(id),
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    elevation DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    region_id UUID REFERENCES region(id)
);

CREATE TABLE geo_object_alias (
    id SERIAL PRIMARY KEY,
    geo_object_id UUID NOT NULL REFERENCES geo_object(id),
    alias_name VARCHAR(100) NOT NULL,          -- "Дом у Корней"
    created_by_character_id UUID,
    created_at TIMESTAMP DEFAULT NOW(),
    is_approved BOOLEAN DEFAULT false
);
