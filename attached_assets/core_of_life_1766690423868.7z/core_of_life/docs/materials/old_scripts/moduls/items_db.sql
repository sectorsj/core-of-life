-- === Общее ===
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- === 6. ItemService (items_db) ===
CREATE TABLE item_type (
    id SERIAL PRIMARY KEY,
    name VARCHAR(30) NOT NULL UNIQUE           -- 'weapon', 'armor', 'shield'
);

CREATE TABLE rarity (
    id SERIAL PRIMARY KEY,
    name VARCHAR(20) NOT NULL UNIQUE           -- 'обычный', 'редкий', ...
    sort_order INT NOT NULL
);

CREATE TABLE item (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    item_type_id INT NOT NULL REFERENCES item_type(id),
    rarity_id INT NOT NULL REFERENCES rarity(id),
    material_id INT REFERENCES material(id),
    weight_kg FLOAT,
    size_description TEXT,
    condition TEXT,
    price_gold INT
);

CREATE TABLE weapon (
    item_id UUID PRIMARY KEY REFERENCES item(id),
    damage_dice VARCHAR(20) NOT NULL,          -- '1d6'
    damage_type VARCHAR(20) NOT NULL,          -- 'колющий', 'режущий', 'дробящий'
    range_m INT
);

CREATE TABLE armor (
    item_id UUID PRIMARY KEY REFERENCES item(id),
    armor_category VARCHAR(20) NOT NULL,       -- 'легкий', 'средний', 'тяжелый'
    armor_class_bonus INT NOT NULL
);

-- Монеты (нормализовано!)
CREATE TABLE coin_type (
    id SERIAL PRIMARY KEY,
    code VARCHAR(2) NOT NULL UNIQUE,           -- 'ММ', 'СМ', 'ЗМ', 'ЭМ', 'ПМ'
    name VARCHAR(50) NOT NULL,
    material_id INT NOT NULL REFERENCES material(id),
    nominal_value_in_copper INT NOT NULL       -- номинал в медных монетах
);

CREATE TABLE coin_purse (
    character_id UUID NOT NULL,
    coin_type_id INT NOT NULL REFERENCES coin_type(id),
    amount INT NOT NULL DEFAULT 0 CHECK (amount >= 0),
    PRIMARY KEY (character_id, coin_type_id)
);

CREATE TABLE inventory_item (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    character_id UUID NOT NULL,
    item_id UUID NOT NULL REFERENCES item(id),
    quantity INT NOT NULL DEFAULT 1
);