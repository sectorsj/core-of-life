-- === Общее ===
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- === 3. LivingObjectService (living_db) ===
CREATE TABLE character (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    title VARCHAR(100),                        -- ← Звание от игрока
    father_id UUID REFERENCES character(id),
    mother_id UUID REFERENCES character(id),
    gender VARCHAR(20),
    birth_date DATE,
    birth_place_id UUID NOT NULL,              -- ← без FK (меж-БД связь через API)
    account_id UUID NOT NULL                   -- ← без FK
);

-- Происхождение: геном и тип роста (скрытые механики)
CREATE TABLE origin (
    character_id UUID PRIMARY KEY,
    genome TEXT NOT NULL DEFAULT 'AAAA|TTTT|CCCC|GGGG|ATAT|CGCG|ACGT',
    growth_type VARCHAR(20) CHECK (growth_type IN ('balanced','slow','fast','chosen'))
);

-- Характеристики (6 базовых)
CREATE TABLE ability_score (
    character_id UUID PRIMARY KEY,
    strength INT NOT NULL DEFAULT 10,
    dexterity INT NOT NULL DEFAULT 10,
    constitution INT NOT NULL DEFAULT 10,      -- ← влияет на physiology
    intelligence INT NOT NULL DEFAULT 10,
    wisdom INT NOT NULL DEFAULT 10,
    charisma INT NOT NULL DEFAULT 10
);

-- Навыки (владение)
CREATE TABLE skill (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE           -- 'athletics', 'medicine'
);

CREATE TABLE character_skill (
    character_id UUID NOT NULL,
    skill_id INT NOT NULL,
    has_proficiency BOOLEAN NOT NULL DEFAULT false,
    modifier INT NOT NULL DEFAULT 0,
    PRIMARY KEY (character_id, skill_id)
);

-- Физиология: телесная основа (связана с Ци)
CREATE TABLE physiology (
    character_id UUID PRIMARY KEY,
    body_strength INT NOT NULL DEFAULT 0 CHECK (body_strength BETWEEN 0 AND 100),
    organ_health JSONB,                        -- ← здоровье органов (сердце, лёгкие и т.д.)
    stamina INT NOT NULL DEFAULT 100           -- выносливость (для боя, бега)
);

-- Предыстория
CREATE TABLE backstory (
    character_id UUID PRIMARY KEY,
    personality_traits TEXT,
    worldview TEXT,
    ideals TEXT,
    bonds TEXT,
    flaws TEXT,
    allies TEXT,
    enemies TEXT
);

-- Боевые параметры
CREATE TABLE combat_stats (
    character_id UUID PRIMARY KEY,
    current_hp INT NOT NULL DEFAULT 10,
    max_hp INT NOT NULL DEFAULT 10,
    temp_hp INT NOT NULL DEFAULT 0,
    armor_class INT NOT NULL DEFAULT 10,
    initiative INT NOT NULL DEFAULT 0,
    speed INT NOT NULL DEFAULT 30,
    proficiency_bonus INT NOT NULL DEFAULT 2,
    inspiration INT NOT NULL DEFAULT 0,
    spell_save_dc INT NOT NULL DEFAULT 10,
    spell_attack_bonus INT NOT NULL DEFAULT 0,
    experience_points INT NOT NULL DEFAULT 0,
    completed_sessions INT NOT NULL DEFAULT 0
);

-- Кости хитов и спасброски от смерти
CREATE TABLE hit_dice (
    character_id UUID PRIMARY KEY,
    dice_type VARCHAR(10) NOT NULL,            -- '1d8'
    total_count INT NOT NULL,
    used_count INT NOT NULL DEFAULT 0
);

CREATE TABLE death_saves (
    character_id UUID PRIMARY KEY,
    successes INT NOT NULL DEFAULT 0,
    failures INT NOT NULL DEFAULT 0
);

-- Ячейки заклинаний (остаются здесь, но используются MetaphysicalService)
CREATE TABLE spell_slot (
    character_id UUID NOT NULL,
    spell_level INT NOT NULL CHECK (spell_level BETWEEN 1 AND 9),
    total_slots INT NOT NULL,
    used_slots INT NOT NULL DEFAULT 0,
    PRIMARY KEY (character_id, spell_level)
);

-- Туман войны
CREATE TABLE fog_of_war (
    character_id UUID NOT NULL,
    geo_object_id UUID,
    region_id UUID,
    discovered_at TIMESTAMP DEFAULT NOW(),
    is_explored BOOLEAN DEFAULT false,
    PRIMARY KEY (character_id, geo_object_id, region_id)
);

-- Активные процессы поглощения (стихии, энергия)
CREATE TABLE active_absorption (
    character_id UUID PRIMARY KEY,
    region_id UUID NOT NULL,
    energy_color VARCHAR(20) NOT NULL,
    started_at TIMESTAMP DEFAULT NOW(),
    duration_minutes INT NOT NULL DEFAULT 15,
    is_completed BOOLEAN DEFAULT false
);

CREATE TABLE elemental_absorption (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    character_id UUID NOT NULL,
    element_type VARCHAR(20) NOT NULL,  -- 'cold', 'fire', 'lightning'
    status VARCHAR(20) DEFAULT 'pending',
    started_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP,
    cost_hp INT NOT NULL
);

-- Индексы
CREATE INDEX idx_fog_char ON fog_of_war(character_id);
CREATE INDEX idx_fog_region ON fog_of_war(region_id);