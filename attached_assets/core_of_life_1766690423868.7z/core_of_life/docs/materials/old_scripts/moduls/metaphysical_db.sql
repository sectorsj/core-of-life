-- === Общее ===
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- === 1. Чакры (справочник) ===
CREATE TABLE chakra (
    id SERIAL PRIMARY KEY,
    name VARCHAR(30) NOT NULL UNIQUE,          -- 'muladhara', 'anahata'
    display_name VARCHAR(50) NOT NULL,
    color VARCHAR(20) NOT NULL,                -- 'red', 'green'
    position INT NOT NULL UNIQUE CHECK (position BETWEEN 1 AND 7),
    required_lower_chakra_id INT REFERENCES chakra(id),
    required_openness_threshold FLOAT DEFAULT 0.5
);

-- === 2. Состояние чакр персонажа ===
-- (заменяет character_chakra И chakra_state)
CREATE TABLE character_chakra (
    character_id UUID NOT NULL,                -- ← из living_db (без FK)
    chakra_id INT NOT NULL REFERENCES chakra(id),
    sequence VARCHAR(12) NOT NULL,             -- генетический код чакры
    openness FLOAT NOT NULL DEFAULT 0.0 CHECK (openness BETWEEN 0 AND 1),
    energy_level INT NOT NULL DEFAULT 0 CHECK (energy_level BETWEEN 0 AND 100),
    has_ever_been_opened BOOLEAN NOT NULL DEFAULT false,
    PRIMARY KEY (character_id, chakra_id)
);

-- === 3. Метафизический профиль ===
-- Метафизический профиль: разделение Ци и Энергии Чакр
CREATE TABLE metaphysical_profile (
    character_id UUID PRIMARY KEY,

    -- Ци (телесная жизненная сила)
    qi_capacity INT NOT NULL DEFAULT 50 CHECK (qi_capacity BETWEEN 0 AND 100),
    qi_flow INT NOT NULL DEFAULT 5 CHECK (qi_flow BETWEEN 0 AND 100),
    qi_purity FLOAT NOT NULL DEFAULT 0.7 CHECK (qi_purity BETWEEN 0 AND 1),
    
    -- Энергия Чакр (тонкая духовная сила)
    chakra_energy_capacity INT NOT NULL DEFAULT 50 CHECK (chakra_energy_capacity BETWEEN 0 AND 100),
    chakra_energy_flow INT NOT NULL DEFAULT 5 CHECK (chakra_energy_flow BETWEEN 0 AND 100),
    
    -- Аура и карма
    aura_radius DOUBLE PRECISION NOT NULL DEFAULT 1.0,
    karma_balance INT NOT NULL DEFAULT 0
);

-- === 4. Заклинания (из architect.txt) ===
CREATE TABLE spell (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    character_id UUID NOT NULL,                -- ← из living_db
    name VARCHAR(100) NOT NULL,
    magic_school VARCHAR(50) NOT NULL,         -- "ШколаМагии"
    range_m INT NOT NULL,                      -- "Дистанция"
    casting_time_sec INT NOT NULL,             -- "ВремяСотворения"
    duration_sec INT NOT NULL,                 -- "Продолжительность"
    effect_description TEXT NOT NULL           -- "ЭффектЗаклинания"
);

-- Компоненты заклинаний
CREATE TABLE spell_component (
    spell_id UUID NOT NULL REFERENCES spell(id) ON DELETE CASCADE,
    component_type VARCHAR(20) NOT NULL CHECK (component_type IN ('verbal', 'somatic', 'material')),
    material_description TEXT,                 -- заполняется, если тип = material
    PRIMARY KEY (spell_id, component_type)
);

-- Ячейки заклинаний (из architect.txt: "ЯчейкаЗаклинаний")
CREATE TABLE spell_slot (
    character_id UUID NOT NULL,                -- ← из living_db
    spell_level INT NOT NULL CHECK (spell_level BETWEEN 1 AND 9),
    total_slots INT NOT NULL,
    used_slots INT NOT NULL DEFAULT 0,
    PRIMARY KEY (character_id, spell_level)
);

-- === 5. Эгрегоры ===
CREATE TABLE egregore (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    collective_power INT NOT NULL DEFAULT 0
);

CREATE TABLE character_egregore (
    character_id UUID NOT NULL,                -- ← из living_db
    egregore_id UUID NOT NULL REFERENCES egregore(id),
    joined_at TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (character_id, egregore_id)
);

-- === 6. Карма ===
CREATE TABLE karmic_action (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    character_id UUID NOT NULL,                -- ← из living_db
    action_type VARCHAR(50) NOT NULL,          -- 'help', 'harm', 'deceit'
    consequence_delay INT,                     -- через сколько событий
    created_at TIMESTAMP DEFAULT NOW()
);

-- === 7. Стихии и совместимость (для комплементации) ===
CREATE TABLE elemental_affinity (
    character_id UUID NOT NULL,
    element_type VARCHAR(20) NOT NULL CHECK (element_type IN ('cold', 'fire', 'lightning', 'earth', 'air', 'water')),
    affinity_level INT NOT NULL DEFAULT 0 CHECK (affinity_level BETWEEN 0 AND 100),
    PRIMARY KEY (character_id, element_type)
);