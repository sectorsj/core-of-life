CREATE TABLE notification (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    character_id UUID NOT NULL,
    title VARCHAR(100) NOT NULL,          -- "Новый навык!", "Энергия поглощена"
    message TEXT NOT NULL,                -- "Вы получили владение: Природа"
    event_type VARCHAR(50) NOT NULL,      -- "skill_acquired", "chakra_opened"
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_notification_char ON notification(character_id);