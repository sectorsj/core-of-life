-- Физические константы мира
CREATE TABLE world_physics (
    id SERIAL PRIMARY KEY,
    gravity_m_s2 DOUBLE PRECISION DEFAULT 9.8,
    air_density_kg_m3 DOUBLE PRECISION DEFAULT 1.225,
    water_density_kg_m3 DOUBLE PRECISION DEFAULT 1000.0
);

-- Влияние погоды на физику
CREATE TABLE weather_physics_modifier (
    weather_type VARCHAR(50) PRIMARY KEY,
    movement_speed_modifier DOUBLE PRECISION DEFAULT 1.0,  -- 0.8 = медленнее в дождь
    visibility_modifier DOUBLE PRECISION DEFAULT 1.0,      -- 0.5 = туман
    projectile_accuracy_modifier DOUBLE PRECISION DEFAULT 1.0
);