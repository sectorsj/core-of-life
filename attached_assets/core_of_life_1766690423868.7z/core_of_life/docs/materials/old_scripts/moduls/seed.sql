-- === 1. GeoService ===
INSERT INTO material (name, density, color_rgb) VALUES
('медь', 8.96, '[184, 115, 51]'),
('серебро', 10.49, '[192, 192, 192]'),
('золото', 19.32, '[255, 215, 0]'),
('электрум', 13.0, '[212, 175, 55]'),
('платина', 21.45, '[229, 228, 226]');

INSERT INTO geo_object_type (name) VALUES
('village'), ('forest'), ('mountain'), ('ruins');

INSERT INTO region (id, name) VALUES
('11111111-1111-1111-1111-111111111111', 'Зелёный Край');

INSERT INTO region_vertex (region_id, latitude, longitude, elevation, vertex_order) VALUES
('11111111-1111-1111-1111-111111111111', 45.100, 32.400, 120, 1),
('11111111-1111-1111-1111-111111111111', 45.100, 32.500, 120, 2),
('11111111-1111-1111-1111-111111111111', 45.200, 32.500, 125, 3),
('11111111-1111-1111-1111-111111111111', 45.200, 32.400, 125, 4);

INSERT INTO geo_object (id, name, type_id, latitude, longitude, elevation, region_id) VALUES
('33333333-3333-3333-3333-333333333333', 'Деревня Зелёный Мох',
 (SELECT id FROM geo_object_type WHERE name = 'village'),
 45.150, 32.450, 122, '11111111-1111-1111-1111-111111111111');

INSERT INTO geo_object_alias (geo_object_id, alias_name) VALUES
('33333333-3333-3333-3333-333333333333', 'Дом у Корней');

-- === 2. AuthService ===
INSERT INTO account (id, email, password_hash) VALUES
('44444444-4444-4444-4444-444444444444', 'player@example.com', 'hashed_password_123');

-- === 3. LivingObjectService ===
INSERT INTO character (id, name, title, gender, birth_date, birth_place_id, account_id) VALUES
('55555555-5555-5555-5555-555555555555', 'Лира', 'Голос корней', 'female', '2025-01-01',
 '33333333-3333-3333-3333-333333333333',
 '44444444-4444-4444-4444-444444444444');

INSERT INTO origin (character_id, genome, growth_type) VALUES
('55555555-5555-5555-5555-555555555555', 'ATAT|TCTC|AGAG|CGCG|GTGT|CACA|CGGC', 'balanced');

INSERT INTO ability_score (character_id, strength, dexterity, constitution, intelligence, wisdom, charisma) VALUES
('55555555-5555-5555-5555-555555555555', 14, 16, 12, 10, 18, 13);

INSERT INTO skill (name) VALUES
('athletics'), ('stealth'), ('medicine'), ('nature'), ('survival');

INSERT INTO character_skill (character_id, skill_id, has_proficiency, modifier) VALUES
('55555555-5555-5555-5555-555555555555', (SELECT id FROM skill WHERE name = 'athletics'), true, 5),
('55555555-5555-5555-5555-555555555555', (SELECT id FROM skill WHERE name = 'stealth'), true, 6),
('55555555-5555-5555-5555-555555555555', (SELECT id FROM skill WHERE name = 'medicine'), true, 7),
('55555555-5555-5555-5555-555555555555', (SELECT id FROM skill WHERE name = 'nature'), true, 4),
('55555555-5555-5555-5555-555555555555', (SELECT id FROM skill WHERE name = 'survival'), true, 5);

INSERT INTO physiology (character_id, body_strength) VALUES
('55555555-5555-5555-5555-555555555555', 45);

INSERT INTO mana (character_id, capacity, flow, purity) VALUES
('55555555-5555-5555-5555-555555555555', 80, 12, 0.85);

INSERT INTO energy_reserve (character_id, green, yellow) VALUES
('55555555-5555-5555-5555-555555555555', 30, 10);

INSERT INTO backstory (character_id, personality_traits, worldview, ideals, bonds, flaws, allies, enemies) VALUES
('55555555-5555-5555-5555-555555555555',
 'спокойная, любопытная',
 'нейтральное',
 'гармония с природой',
 'защита леса Зелёный Мох',
 'не доверяет городским жителям',
 'Друидский Круг',
 'Лесорубы');

INSERT INTO combat_stats (
    character_id, current_hp, max_hp, temp_hp, armor_class, initiative, speed,
    proficiency_bonus, inspiration, spell_save_dc, spell_attack_bonus,
    experience_points, completed_sessions
) VALUES (
    '55555555-5555-5555-5555-555555555555',
    38, 42, 0, 14, 3, 30,
    3, 1, 14, 6,
    6500, 12
);

INSERT INTO hit_dice (character_id, dice_type, total_count, used_count) VALUES
('55555555-5555-5555-5555-555555555555', '1d8', 5, 2);

INSERT INTO death_saves (character_id, successes, failures) VALUES
('55555555-5555-5555-5555-555555555555', 1, 0);

INSERT INTO spell_slot (character_id, spell_level, total_slots, used_slots) VALUES
('55555555-5555-5555-5555-555555555555', 1, 4, 1),
('55555555-5555-5555-5555-555555555555', 2, 3, 0);

-- === 4. GeneticsService ===
INSERT INTO physiological_mutation (name, display_name, effect_json) VALUES
('sensitive_skin', 'Чувствительная кожа', '{"energy_absorption_green": 0.25}');

INSERT INTO character_mutation (character_id, mutation_id) VALUES
('55555555-5555-5555-5555-555555555555', (SELECT id FROM physiological_mutation WHERE name = 'sensitive_skin'));

-- === 5. EnergyService ===
INSERT INTO chakra (name, display_name, color, position) VALUES
('muladhara', 'Муладхара', 'red', 1),
('svadhisthana', 'Свадхистхана', 'orange', 2),
('manipura', 'Манипура', 'yellow', 3),
('anahata', 'Анахата', 'green', 4),
('vishuddha', 'Вишудха', 'blue', 5),
('ajna', 'Аджна', 'indigo', 6),
('sahasrara', 'Сахасрара', 'violet', 7);

INSERT INTO character_chakra (character_id, chakra_id, sequence, openness, energy_level, has_ever_been_opened) VALUES
('55555555-5555-5555-5555-555555555555', (SELECT id FROM chakra WHERE name = 'muladhara'), 'ATATAT', 0.6, 70, true),
('55555555-5555-5555-5555-555555555555', (SELECT id FROM chakra WHERE name = 'anahata'), 'CGCGCG', 0.3, 20, false);

-- === 6. ItemService ===
INSERT INTO item_type (name) VALUES
('weapon'), ('armor'), ('shield'), ('tool'), ('other');

INSERT INTO rarity (name, sort_order) VALUES
('обычный', 1),
('редкий', 2),
('экстра', 3),
('эпический', 4),
('легенда', 5),
('мифический', 6),
('катастрофа', 7);

-- Предмет: Посох друида
INSERT INTO item (id, name, item_type_id, rarity_id, material_id, weight_kg) VALUES
('66666666-6666-6666-6666-666666666666', 'Посох друида',
 (SELECT id FROM item_type WHERE name = 'weapon'),
 (SELECT id FROM rarity WHERE name = 'редкий'),
 (SELECT id FROM material WHERE name = 'золото'), 2.0);

INSERT INTO weapon (item_id, damage_dice, damage_type, range_m) VALUES
('66666666-6666-6666-6666-666666666666', '1d6', 'дробящий', 0);

-- Монеты
INSERT INTO coin_type (code, name, material_id, nominal_value_in_copper) VALUES
('ММ', 'Медные монеты', (SELECT id FROM material WHERE name = 'медь'), 1),
('СМ', 'Серебряные монеты', (SELECT id FROM material WHERE name = 'серебро'), 10),
('ЗМ', 'Золотые монеты', (SELECT id FROM material WHERE name = 'золото'), 100),
('ЭМ', 'Электрумовые монеты', (SELECT id FROM material WHERE name = 'электрум'), 50),
('ПМ', 'Платиновые монеты', (SELECT id FROM material WHERE name = 'платина'), 1000);

INSERT INTO coin_purse (character_id, coin_type_id, amount) VALUES
('55555555-5555-5555-5555-555555555555', (SELECT id FROM coin_type WHERE code = 'ММ'), 30),
('55555555-5555-5555-5555-555555555555', (SELECT id FROM coin_type WHERE code = 'СМ'), 140),
('55555555-5555-5555-5555-555555555555', (SELECT id FROM coin_type WHERE code = 'ЗМ'), 25);

INSERT INTO inventory_item (character_id, item_id, quantity) VALUES
('55555555-5555-5555-5555-555555555555', '66666666-6666-6666-6666-666666666666', 1);

-- === 7. WeatherService ===
INSERT INTO climate_type (name, temperature_base, humidity_level) VALUES
('умеренный лес', 15, 70);

INSERT INTO region_climate (region_id, climate_type_id) VALUES
('11111111-1111-1111-1111-111111111111', (SELECT id FROM climate_type WHERE name = 'умеренный лес'));

INSERT INTO current_weather (region_id, time_of_day, season, weather_type, magical_intensity) VALUES
('11111111-1111-1111-1111-111111111111', 'day', 'spring', 'clear', 0.1);