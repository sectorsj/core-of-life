-- Вещества (расширение material)
CREATE TABLE substance (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,      -- 'вода', 'огонь', 'эфир'
    type VARCHAR(30) NOT NULL CHECK (type IN ('element', 'compound', 'magical')),
    density DOUBLE PRECISION,
    state VARCHAR(20) DEFAULT 'solid',      -- solid, liquid, gas, plasma
    magical_potential FLOAT DEFAULT 0.0     -- влияет на заклинания
);

CREATE TABLE material (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,          -- 'золото', 'серебро', 'медь'
    density DOUBLE PRECISION,                  -- г/см³
    color_rgb JSONB                            -- [R, G, B]
    substance_id INT REFERENCES substance(id),
);