-- === Общее ===
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- === 7. WeatherService (weather_db) ===
CREATE TABLE climate_type (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    temperature_base INT NOT NULL,
    humidity_level INT NOT NULL CHECK (humidity_level BETWEEN 0 AND 100)
);

CREATE TABLE region_climate (
    region_id UUID PRIMARY KEY,
    climate_type_id INT NOT NULL REFERENCES climate_type(id)
);

CREATE TABLE current_weather (
    region_id UUID PRIMARY KEY,
    time_of_day VARCHAR(20) NOT NULL,
    season VARCHAR(20) NOT NULL,
    weather_type VARCHAR(50),
    magical_intensity FLOAT DEFAULT 0.0,
    updated_at TIMESTAMP DEFAULT NOW()
);